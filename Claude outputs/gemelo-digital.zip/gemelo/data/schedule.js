// Horario semanal de Jherson (zona America/Lima). EDITA ESTE ARCHIVO para ajustar tu semana.
// Días: 0=Dom 1=Lun 2=Mar 3=Mié 4=Jue 5=Vie 6=Sáb. Horas "HH:MM".
// Lo que no esté cubierto queda como "libre" (en casa). El sueño se calcula con wake/bed.

const T = (s) => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };

const CONFIG = {
  tz: 'America/Lima',
  gymStart: '2026-11-17', // el gym arranca desde mañana; la primera sesión de tu horario cae el jueves 19
  wake: { 0: '06:30', 1: '06:00', 2: '06:00', 3: '06:00', 4: '06:00', 5: '06:00', 6: '06:30' },
  bed:  { 0: '22:00', 1: '22:00', 2: '22:00', 3: '22:30', 4: '22:30', 5: '22:00', 6: '22:00' },
};

const blocks = [];
function b(days, start, end, state, label, extra = {}) {
  for (const d of [].concat(days)) blocks.push({ day: d, start: T(start), end: T(end), state, label, ...extra });
}

// ---------- Cursos (de tu horario UPAO) ----------
const GP = { course: 'Gestión de Proyectos de SI', code: 'ICSI-678' };
const ML = { course: 'Machine Learning', code: 'ISIA-110' };
const AU = { course: 'Automatización Inteligente de Procesos', code: 'ISIA-114' };
const BD = { course: 'Big Data y Analítica de Datos', code: 'ISIA-116' };
const PI = { course: 'Proyecto de Investigación', code: 'ISIA-117' };
const CD = { course: 'Customer Development', code: 'ISIA-113' };

// ---------- LUNES ----------
b(1, '06:30', '07:45', 'gym', 'Gym');
b(1, '07:45', '08:00', 'camino', 'Rumbo al taxi', { to: 'taxi' });
b(1, '08:00', '09:30', 'taxi', 'Taxi');
b(1, '09:30', '10:00', 'camino', 'Volviendo a casa', { to: 'casa' });
b(1, '10:00', '15:00', 'codigo', 'Programar (bloque fijo)');
b(1, '15:30', '16:10', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(1, '16:10', '18:00', 'clases', 'Teoría', { ...GP, kind: 'Teoría', aula: 'G704', nrc: '5054' });
b(1, '18:00', '19:45', 'clases', 'Práctica', { ...GP, kind: 'Práctica', aula: 'G704', nrc: '5055' });
b(1, '19:45', '20:15', 'camino', 'Volviendo a casa', { to: 'casa' });

// ---------- MARTES ----------
b(2, '06:30', '07:00', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(2, '07:00', '08:50', 'clases', 'Teoría', { ...ML, kind: 'Teoría', aula: 'G602', nrc: '5045' });
b(2, '08:50', '12:25', 'clases', 'Laboratorio', { ...ML, kind: 'Laboratorio', aula: 'G401', nrc: '5046' });
b(2, '12:25', '13:00', 'camino', 'Volviendo a casa', { to: 'casa' });
b(2, '13:00', '15:30', 'codigo', 'Programar (bloque fijo)');
b(2, '15:30', '16:10', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(2, '16:10', '17:55', 'clases', 'Laboratorio', { ...GP, kind: 'Laboratorio', aula: 'G701', nrc: '9763' });
b(2, '17:55', '18:30', 'camino', 'Rumbo al taxi', { to: 'taxi' });
b(2, '18:30', '21:00', 'taxi', 'Taxi');

// ---------- MIÉRCOLES ----------
b(3, '06:30', '07:00', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(3, '07:00', '08:45', 'clases', 'Teoría', { ...AU, kind: 'Teoría', aula: 'G602', nrc: '6807' });
b(3, '08:45', '10:40', 'estudio', 'Hueco en campus: estudiar', {});
b(3, '10:40', '12:25', 'clases', 'Laboratorio', { ...AU, kind: 'Laboratorio', aula: 'F402', nrc: '6809' });
b(3, '12:25', '13:00', 'camino', 'Volviendo a casa', { to: 'casa' });
b(3, '13:00', '15:30', 'codigo', 'Programar (bloque fijo)');
b(3, '15:30', '16:10', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(3, '16:10', '18:00', 'clases', 'Teoría', { ...BD, kind: 'Teoría', nrc: '6814' });
b(3, '18:00', '21:35', 'clases', 'Laboratorio', { ...BD, kind: 'Laboratorio', nrc: '6815' });
b(3, '21:35', '22:15', 'camino', 'Volviendo a casa', { to: 'casa' });

// ---------- JUEVES ----------
b(4, '06:30', '12:00', 'taxi', 'Taxi (mañana)');
b(4, '15:00', '16:15', 'gym', 'Gym');
b(4, '17:30', '18:00', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(4, '18:00', '19:50', 'clases', 'Teoría', { ...PI, kind: 'Teoría', aula: 'G201', nrc: '5666' });
b(4, '19:50', '21:35', 'clases', 'Práctica', { ...PI, kind: 'Práctica', aula: 'G201', nrc: '5667' });
b(4, '21:35', '22:15', 'camino', 'Volviendo a casa', { to: 'casa' });

// ---------- VIERNES ----------
b(5, '06:30', '07:00', 'camino', 'Rumbo a la universidad', { to: 'uni' });
b(5, '07:00', '08:50', 'clases', 'Teoría', { ...CD, kind: 'Teoría', aula: 'G504', nrc: '5041' });
b(5, '08:50', '10:35', 'clases', 'Laboratorio', { ...CD, kind: 'Laboratorio', aula: 'G701', nrc: '5042' });
b(5, '10:35', '11:00', 'camino', 'Volviendo a casa', { to: 'casa' });
b(5, '11:00', '14:30', 'codigo', 'Programar (bloque fijo)');
b(5, '14:30', '15:00', 'camino', 'Rumbo al taxi', { to: 'taxi' });
b(5, '15:00', '21:00', 'taxi', 'Taxi (tarde)');

// ---------- SÁBADO ----------
b(6, '07:00', '08:15', 'gym', 'Gym');
b(6, '08:15', '09:00', 'camino', 'Rumbo al taxi', { to: 'taxi' });
b(6, '09:00', '13:00', 'taxi', 'Taxi (mañana)');
b(6, '14:30', '15:00', 'camino', 'Rumbo al taxi', { to: 'taxi' });
b(6, '15:00', '21:00', 'taxi', 'Taxi (tarde)');

// ---------- DOMINGO ----------
b(0, '09:00', '13:00', 'taxi', 'Taxi (mañana)');
b(0, '14:30', '15:00', 'camino', 'Rumbo al taxi', { to: 'taxi' });
b(0, '15:00', '18:30', 'taxi', 'Taxi (tarde)');
b(0, '18:30', '22:00', 'descanso', 'Descanso (sin estudio)');

module.exports = { CONFIG, blocks, T };
