# Gemelo digital · Mi día

Página local que muestra tu avatar en la escena que toca según tu horario real (casa, universidad, taxi, gym) y una computadora con tus proyectos (Finzo, Paso, Lleva y esta página).

## Correrlo
1. Instala **Node.js 18 o superior** (https://nodejs.org). No hace falta `npm install`.
2. En Windows haz doble clic en `iniciar.bat`. En otros sistemas: `node server.js`.
3. Abre http://localhost:3737

El servidor solo escucha en `127.0.0.1`: únicamente tu computadora puede verlo.

## Qué hace cada cosa
- **Horario:** `data/schedule.js`. Es lo único que tienes que editar para ajustar tu semana (taxi, clases, código, gym). Hay horarios **supuestos** marcados abajo.
- **Estado manual:** botón "Cambiar estado". Gana sobre el horario y caduca solo (30 min a 8 h).
- **Vista previa:** toca un bloque de la línea de tiempo, o un bloque de "Mi semana" (calendario de la pared), para ver esa escena. No cambia tu estado.
- **Gym:** el gym arranca según `gymStart` en `data/schedule.js`. Tú marcas cada sesión en la pizarra del gym o en el panel de tu avatar; nada se detecta solo. La racha cuenta sesiones programadas seguidas.
- **Commits reales:** `data/config.json` lista las carpetas de tus repos. El servidor ejecuta `git log` y `git status` (solo lectura) y muestra los commits de hoy en la pantalla del monitor, en el chip "$ N commits hoy" y en la pestaña Actividad. Necesita `git` instalado.
- **Maqueta:** botón "Maqueta" sobre la escena. Muestra todo a la vez, como un diorama visto desde arriba: casa, universidad, gym, la calle con el taxi y un distrito de proyectos. Arrastra para girar, rueda o +/− para acercar, "Desde arriba" para el plano. Tu avatar camina por las calles entre lugares según el horario. Cada torre es un proyecto y su altura son los commits de los últimos 30 días (lectura real del repo; si no encuentra la carpeta usa el dato guardado de la ficha). La bandera naranja avisa de cambios sin commitear. Abre con `?vista=maqueta`.
- **Computadora:** pestañas Resumen, Interfaces, Arquitectura, Stack, Actividad y Pendientes. Fichas en `data/projects.json` y `data/self.json`; pantallas en `public/projects/<proyecto>/`.

## Horarios que supuse (confírmalos o corrígelos en `data/schedule.js`)
- Taxi del jueves en la mañana: 06:30 a 12:00.
- Taxi del domingo en la mañana: 09:00 a 13:00.
- Taxi del viernes en la tarde: 15:00 a 21:00.
- Martes: el taxi empieza a las 18:30 (salida del laboratorio a las 17:55 más el traslado).
- Dormir a las 22:00, y a las 22:30 miércoles y jueves (salen de clase a las 21:35).
- Bloques de código fijos: lun 10:00–15:00, mar y mié 13:00–15:30, vie 11:00–14:30.

## Lo que NO es
- El horario es el **plan**, no un registro. Las horas de taxi, clases y código son planeadas, no medidas. Los commits sí son reales.
- No se conecta a WhatsApp todavía.

## Seguridad
- Solo `127.0.0.1`. No cambies el host a `0.0.0.0` sin añadir autenticación: cualquiera en tu red podría cambiar tu estado.
- Las escrituras (`POST`/`DELETE`) exigen la cabecera `X-Gemelo` y un `Host` de localhost, para que otras páginas abiertas en tu navegador no puedan llamarlas.
- La pestaña de proyectos oculta cualquier texto que mencione credenciales, claves o secretos. Aun así, no pegues secretos en `data/*.json`.
- Antes de publicar o grabar la página: los diseños incluyen datos de ejemplo, y los proyectos de clientes deberían anonimizarse.

## Estructura
```
server.js            servidor (Node, sin dependencias)
data/schedule.js     tu semana
data/config.json     carpetas de tus repos y puerto
data/projects.json   fichas de Finzo, Paso y Lleva (leídas del código)
data/self.json       ficha de esta página
public/              interfaz (HTML, CSS, JS, SVG); maqueta.js es la vista 3D
public/projects/     pantallas de Claude Design de cada proyecto
```

## Cambiar la hora para probar
Agrega `?at=2026-11-19T15:30` a la URL para ver cómo se vería ese momento (hora de Lima).
