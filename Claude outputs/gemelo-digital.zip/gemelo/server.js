#!/usr/bin/env node
// Gemelo digital de Jherson — servidor local SIN dependencias (solo Node >= 18).
// Uso:  node server.js   →  http://localhost:3737
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { CONFIG, blocks, T } = require('./data/schedule');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');

// ------------------------------------------------------------------ config
function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
const userCfg = readJSON(path.join(DATA, 'config.json'), {});
const PORT = Number(process.env.PORT || userCfg.port || 3737);
const HOST = '127.0.0.1'; // solo tu computadora. NO cambiar a 0.0.0.0 sin leer el README.
const REPOS = Array.isArray(userCfg.repos) ? userCfg.repos : [];

// ------------------------------------------------------------------ estado persistente (override + gym)
const RUNTIME_FILE = path.join(DATA, 'runtime.json');
let runtime = Object.assign({ override: null, gymLog: {} }, readJSON(RUNTIME_FILE, {}));
function saveRuntime() {
  try { fs.writeFileSync(RUNTIME_FILE, JSON.stringify(runtime, null, 2)); } catch (e) { console.error('No pude guardar runtime.json:', e.message); }
}

// ------------------------------------------------------------------ tiempo (Lima = UTC-5 fijo, sin horario de verano)
const LIMA_OFFSET_MS = -5 * 3600 * 1000;
function limaParts(ms) {
  const d = new Date(ms + LIMA_OFFSET_MS);
  const y = d.getUTCFullYear(), mo = d.getUTCMonth() + 1, da = d.getUTCDate();
  return {
    y, mo, da,
    dow: d.getUTCDay(),
    minutes: d.getUTCHours() * 60 + d.getUTCMinutes(),
    seconds: d.getUTCSeconds(),
    date: `${y}-${String(mo).padStart(2, '0')}-${String(da).padStart(2, '0')}`,
  };
}
function limaMidnightMs(dateStr) { // ms UTC del 00:00 Lima de esa fecha
  const [y, m, d] = dateStr.split('-').map(Number);
  return Date.UTC(y, m - 1, d) - LIMA_OFFSET_MS;
}
function addDays(dateStr, n) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + n));
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}-${String(dt.getUTCDate()).padStart(2, '0')}`;
}
const hhmm = (min) => `${String(Math.floor(min / 60) % 24).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;

// ------------------------------------------------------------------ el día completo como lista de bloques
function dayBlocks(dow, dateStr) {
  const wake = T(CONFIG.wake[dow]);
  const bed = T(CONFIG.bed[dow]);
  const slots = new Array(1440).fill(null);
  const mk = (state, label, extra = {}) => ({ state, label, ...extra });
  const libre = mk('libre', 'Tiempo libre');
  slots.fill(libre);
  const sleepA = mk('dormir', 'Durmiendo');
  const sleepB = mk('dormir', 'Durmiendo');
  const wakeB = mk('despertar', 'Despertar');
  for (let m = 0; m < wake; m++) slots[m] = sleepA;
  for (let m = wake; m < Math.min(wake + 30, 1440); m++) slots[m] = wakeB;
  for (let m = bed; m < 1440; m++) slots[m] = sleepB;
  for (const blk of blocks) {
    if (blk.day !== dow) continue;
    let st = blk;
    if (blk.state === 'gym' && dateStr < CONFIG.gymStart) st = mk('libre', 'Tiempo libre (el gym empieza el ' + CONFIG.gymStart + ')');
    for (let m = blk.start; m < blk.end && m < 1440; m++) slots[m] = st;
  }
  const out = [];
  let start = 0;
  for (let m = 1; m <= 1440; m++) {
    if (m === 1440 || slots[m] !== slots[start]) {
      const s = slots[start];
      out.push({ ...s, day: undefined, start, end: m, startHM: hhmm(start), endHM: m === 1440 ? '24:00' : hhmm(m) });
      start = m;
    }
  }
  return out;
}

// ------------------------------------------------------------------ gym
function gymStatus(nowMs) {
  const p = limaParts(nowMs);
  const gymBlockOn = (date, dow) => dayBlocks(dow, date).find((x) => x.state === 'gym');
  const todayBlk = gymBlockOn(p.date, p.dow);
  const doneToday = !!runtime.gymLog[p.date];
  let streak = 0;
  for (let i = 0; i < 70; i++) {
    const date = addDays(p.date, -i);
    const dow = limaParts(limaMidnightMs(date) + 12 * 3600e3).dow;
    const blk = gymBlockOn(date, dow);
    if (!blk) continue;
    if (i === 0 && !runtime.gymLog[date] && p.minutes < blk.end) continue; // hoy aún puede cumplirse
    if (runtime.gymLog[date]) streak++; else break;
  }
  let nextDate = null;
  for (let i = 0; i < 8; i++) {
    const date = addDays(p.date, i);
    const dow = limaParts(limaMidnightMs(date) + 12 * 3600e3).dow;
    const blk = gymBlockOn(date, dow);
    if (blk && (i > 0 || p.minutes < blk.end)) { nextDate = { date, startHM: blk.startHM, endHM: blk.endHM }; break; }
  }
  return {
    streak, doneToday,
    scheduledToday: !!todayBlk && p.date >= CONFIG.gymStart,
    todayWindow: todayBlk ? `${todayBlk.startHM}–${todayBlk.endHM}` : null,
    next: nextDate,
    sessionsLogged: Object.keys(runtime.gymLog).filter((k) => runtime.gymLog[k]).length,
    gymStart: CONFIG.gymStart,
  };
}

// ------------------------------------------------------------------ estado completo
function buildState(nowMs, simulated) {
  const p = limaParts(nowMs);
  const day = dayBlocks(p.dow, p.date);
  const idx = day.findIndex((x) => p.minutes >= x.start && p.minutes < x.end);
  let current = { ...day[idx] };
  let next = day.slice(idx + 1).find((x) => x.state !== current.state || x.label !== current.label) || null;
  if (!next) { // primer bloque relevante de mañana
    const tp = limaParts(limaMidnightMs(addDays(p.date, 1)) + 12 * 3600e3);
    const td = dayBlocks(tp.dow, addDays(p.date, 1));
    next = { ...td.find((x) => x.state !== 'dormir' && x.state !== 'despertar' && x.state !== 'libre') || td[0], tomorrow: true };
  }
  let override = null;
  if (!simulated && runtime.override) {
    if (runtime.override.until && runtime.override.until <= nowMs) { runtime.override = null; saveRuntime(); }
    else override = runtime.override;
  }
  let sinceMs = limaMidnightMs(p.date) + current.start * 60000;
  if (override) {
    current = { state: override.state, label: override.label || 'Estado manual', manual: true, start: 0, end: 0 };
    sinceMs = override.since;
  }
  // el bloque "libre" o "dormir" continuo puede venir de ayer: se muestra desde la hora del bloque
  const planned = {};
  for (const x of day) planned[x.state] = (planned[x.state] || 0) + (x.end - x.start);
  return {
    now: nowMs, simulated: !!simulated,
    lima: { date: p.date, dow: p.dow, minutes: p.minutes, hm: hhmm(p.minutes), seconds: p.seconds },
    current, sinceMs, override,
    next, day, plannedMinutes: planned,
    gym: gymStatus(nowMs),
    config: { gymStart: CONFIG.gymStart },
  };
}

// ------------------------------------------------------------------ git (commits reales, solo lectura)
const gitCache = { at: 0, data: null };
function gitOne(repo, sinceIso) {
  return new Promise((resolve) => {
    if (!repo.path || !fs.existsSync(repo.path)) return resolve({ slug: repo.slug, name: repo.name, ok: false, reason: 'carpeta no encontrada' });
    const run = (args) => new Promise((res) => execFile('git', ['-C', repo.path, ...args], { timeout: 6000, windowsHide: true, maxBuffer: 1 << 20 }, (err, stdout) => res(err ? null : stdout)));
    Promise.all([
      run(['log', `--since=${sinceIso}`, '--pretty=%h|%ct|%s']),
      run(['log', '-8', '--pretty=%h|%ct|%s']),
      run(['status', '--porcelain']),
      run(['rev-list', '--count', '--since=30.days.ago', 'HEAD']),
      run(['branch', '--show-current']),
    ]).then(([today, recent, status, month, branch]) => {
      if (recent === null) return resolve({ slug: repo.slug, name: repo.name, ok: false, reason: 'git no disponible' });
      const parse = (s) => (s || '').split('\n').filter(Boolean).map((l) => { const [h, t, ...m] = l.split('|'); return { hash: h, ts: Number(t) * 1000, msg: m.join('|').slice(0, 140) }; });
      resolve({ slug: repo.slug, name: repo.name, ok: true, today: parse(today), recent: parse(recent), dirtyFiles: status ? status.split('\n').filter(Boolean).length : 0, commits30d: month ? Number(month.trim()) || 0 : null, branch: branch ? branch.trim() : '' });
    });
  });
}
async function gitState() {
  if (Date.now() - gitCache.at < 45000 && gitCache.data) return gitCache.data;
  const p = limaParts(Date.now());
  const sinceIso = new Date(limaMidnightMs(p.date)).toISOString();
  const repos = await Promise.all(REPOS.map((r) => gitOne(r, sinceIso)));
  gitCache.data = { repos, configured: REPOS.length, commitsToday: repos.reduce((a, r) => a + (r.ok ? r.today.length : 0), 0) };
  gitCache.at = Date.now();
  return gitCache.data;
}

// ------------------------------------------------------------------ proyectos (fichas + pantallas)
function loadProjects() {
  const base = readJSON(path.join(DATA, 'projects.json'), { projects: [] });
  const list = Array.isArray(base) ? base : base.projects || [];
  const self = readJSON(path.join(DATA, 'self.json'), null);
  const all = self ? [...list.filter((x) => x.slug !== self.slug), self] : list;
  for (const pr of all) {
    const sj = readJSON(path.join(PUBLIC, 'projects', pr.slug, 'screens.json'), []);
    pr.screens = sj.map((s) => ({ ...s, url: `/projects/${pr.slug}/screens/${encodeURIComponent(s.file)}` }));
  }
  return all;
}

// ------------------------------------------------------------------ SSE
const clients = new Set();
function broadcast() {
  if (!clients.size) return;
  const payload = `data: ${JSON.stringify(buildState(Date.now(), false))}\n\n`;
  for (const res of clients) res.write(payload);
}
setInterval(broadcast, 15000);

// ------------------------------------------------------------------ HTTP
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function send(res, code, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(code, { 'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}
function hostOk(req) {
  const h = (req.headers.host || '').toLowerCase();
  return h === `localhost:${PORT}` || h === `127.0.0.1:${PORT}`;
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', (c) => { s += c; if (s.length > 10000) { reject(new Error('body')); req.destroy(); } });
    req.on('end', () => { try { resolve(s ? JSON.parse(s) : {}); } catch { reject(new Error('json')); } });
  });
}
const STATES = ['dormir', 'despertar', 'libre', 'codigo', 'estudio', 'gym', 'taxi', 'camino', 'clases', 'descanso'];

const server = http.createServer(async (req, res) => {
  if (!hostOk(req)) return send(res, 403, 'Host no permitido');
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;
  try {
    // ---- API
    if (p === '/api/state' && req.method === 'GET') {
      const at = url.searchParams.get('at'); // "AAAA-MM-DDTHH:MM" hora Lima (vista previa)
      let ms = Date.now(), simulated = false;
      if (at && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(at)) {
        const [d, t] = at.split('T');
        ms = limaMidnightMs(d) + T(t) * 60000; simulated = true;
      }
      return send(res, 200, buildState(ms, simulated));
    }
    if (p === '/api/events' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(`data: ${JSON.stringify(buildState(Date.now(), false))}\n\n`);
      clients.add(res);
      req.on('close', () => clients.delete(res));
      return;
    }
    if (p === '/api/week' && req.method === 'GET') { // lunes a domingo de la semana actual (Lima)
      const today = limaParts(Date.now());
      const mondayOffset = (today.dow + 6) % 7;
      const days = [];
      for (let i = 0; i < 7; i++) {
        const date = addDays(today.date, i - mondayOffset);
        const dow = (i + 1) % 7;
        days.push({ dow, date, isToday: date === today.date, blocks: dayBlocks(dow, date) });
      }
      return send(res, 200, { days });
    }
    if (p === '/api/projects' && req.method === 'GET') return send(res, 200, { projects: loadProjects() });
    if (p === '/api/git' && req.method === 'GET') return send(res, 200, await gitState());

    // ---- escrituras: exigen cabecera propia (bloquea formularios de otras webs hacia localhost)
    if (req.method === 'POST' || req.method === 'DELETE') {
      if (req.headers['x-gemelo'] !== '1') return send(res, 403, 'Falta cabecera X-Gemelo');
      if (p === '/api/override') {
        if (req.method === 'DELETE') { runtime.override = null; saveRuntime(); broadcast(); return send(res, 200, { ok: true }); }
        const body = await readBody(req);
        if (!STATES.includes(body.state)) return send(res, 400, { error: 'estado inválido' });
        const now = Date.now();
        const minutes = Math.min(Math.max(Number(body.minutes) || 60, 5), 12 * 60);
        runtime.override = { state: body.state, label: String(body.label || '').slice(0, 60) || 'Estado manual', since: now, until: now + minutes * 60000 };
        saveRuntime(); broadcast();
        return send(res, 200, { ok: true, override: runtime.override });
      }
      if (p === '/api/gym/checkin') {
        const date = limaParts(Date.now()).date;
        runtime.gymLog[date] = !runtime.gymLog[date];
        saveRuntime(); broadcast();
        return send(res, 200, { ok: true, done: runtime.gymLog[date] });
      }
      return send(res, 404, { error: 'no existe' });
    }

    // ---- estáticos
    let rel = decodeURIComponent(p === '/' ? '/index.html' : p);
    const file = path.normalize(path.join(PUBLIC, rel));
    if (!file.startsWith(PUBLIC + path.sep) && file !== PUBLIC) return send(res, 403, 'No');
    fs.readFile(file, (err, buf) => {
      if (err) return send(res, 404, 'No encontrado');
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(buf);
    });
  } catch (e) {
    send(res, 500, { error: String(e.message || e) });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`\n  Gemelo digital listo →  http://localhost:${PORT}\n  (solo accesible desde esta computadora)\n`);
});
