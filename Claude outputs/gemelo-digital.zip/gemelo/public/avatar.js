// Avatar vectorial de Jherson: corte fade con textura, cejas gruesas, hoodie negro con cordones lima,
// jean negro y zapatillas blancas con detalle lima. Pies en (0,0), mira de frente (o de espaldas).
(function () {
  const C = {
    skin: '#C98B5E', skinD: '#B07548', hair: '#2B2321', hairL: '#4D3D37', brow: '#1A1413',
    hood: '#1E1F24', hoodD: '#121317', hoodL: '#2C2E35', lime: '#B9F03C',
    jeans: '#15181E', jeansL: '#272C36', shoe: '#F5F5F2', sole: '#D4D8D2',
  };
  const f = (n) => Math.round(n * 100) / 100;

  // animateTransform rotate (SMIL). values: lista de grados; keyTimes opcional
  const anim = (vals, dur, kt) =>
    `<animateTransform attributeName="transform" type="rotate" values="${vals}" dur="${dur}s" repeatCount="indefinite"${kt ? ` keyTimes="${kt}" calcMode="linear"` : ''}/>`;

  // ---------------------------------------------------------------- cabeza
  function headFront(o = {}) {
    const look = o.look || 0;      // desplazamiento de pupilas
    const closed = o.eyes === 'closed';
    const smile = o.mouth === 'open'
      ? `<path d="M-6 -121 Q0 -112 6 -121 Z" fill="#6B2E22"/>`
      : `<path d="M-5.5 -121.5 Q0 -118 6.5 -122.5" stroke="#7A3B2A" stroke-width="1.9" fill="none" stroke-linecap="round"/>`;
    const eyes = closed
      ? `<path d="M-12 -133 Q-8 -130.5 -4 -133" stroke="#2B1A14" stroke-width="2" fill="none" stroke-linecap="round"/>
         <path d="M4 -133 Q8 -130.5 12 -133" stroke="#2B1A14" stroke-width="2" fill="none" stroke-linecap="round"/>`
      : `<ellipse cx="${-8 + look}" cy="-133" rx="3.1" ry="3.3" fill="#2B1A14"/><circle cx="${-7 + look}" cy="-134.2" r="1" fill="#fff"/>
         <ellipse cx="${8 + look}" cy="-133" rx="3.1" ry="3.3" fill="#2B1A14"/><circle cx="${9 + look}" cy="-134.2" r="1" fill="#fff"/>`;
    return `<g class="head">
      <rect x="-7.5" y="-123" width="15" height="14" rx="5" fill="${C.skinD}"/>
      <ellipse cx="-20.5" cy="-136" rx="4.2" ry="6" fill="${C.skin}"/><ellipse cx="20.5" cy="-136" rx="4.2" ry="6" fill="${C.skin}"/>
      <path d="M-19.5 -146 C-19.5 -164 19.5 -164 19.5 -146 L19.5 -129 C19.5 -116 9 -111 0 -111 C-9 -111 -19.5 -116 -19.5 -129 Z" fill="${C.skin}"/>
      <path d="M-19.8 -143 C-21 -161 -9 -169 2 -168.5 C14 -168 21 -158 19.8 -143 C18 -149 15 -152 11 -153.5 C5 -150.5 -6 -150.5 -12 -153.5 C-16 -151.5 -18.5 -148 -19.8 -143 Z" fill="${C.hair}"/>
      <path d="M-14 -166 l3 -5 l3 5 M-6 -168 l3 -6 l3 6 M2 -168.5 l3 -6 l3 6 M10 -166 l3 -5 l2 5" fill="${C.hair}" stroke="${C.hair}" stroke-width="1.5" stroke-linejoin="round"/>
      <rect x="-19.5" y="-147" width="4" height="12" rx="2" fill="${C.hairL}" opacity=".55"/><rect x="15.5" y="-147" width="4" height="12" rx="2" fill="${C.hairL}" opacity=".55"/>
      <path d="M-15 -141.5 L-3 -139.6 L-3.2 -136.4 L-15.2 -138.3 Z" fill="${C.brow}"/>
      <path d="M15 -141.5 L3 -139.6 L3.2 -136.4 L15.2 -138.3 Z" fill="${C.brow}"/>
      ${eyes}
      <path d="M-1.5 -131 Q0 -126 1.8 -127" stroke="${C.skinD}" stroke-width="1.6" fill="none" stroke-linecap="round"/>
      ${smile}
    </g>`;
  }

  function headBack() {
    return `<g class="head">
      <rect x="-8" y="-123" width="16" height="14" rx="5" fill="${C.skinD}"/>
      <ellipse cx="-20.5" cy="-136" rx="4.2" ry="6" fill="${C.skin}"/><ellipse cx="20.5" cy="-136" rx="4.2" ry="6" fill="${C.skin}"/>
      <path d="M-19.5 -146 C-19.5 -164 19.5 -164 19.5 -146 L19.5 -129 C19.5 -116 9 -111 0 -111 C-9 -111 -19.5 -116 -19.5 -129 Z" fill="${C.hair}"/>
      <path d="M-19.5 -134 C-17 -120 -9 -112 0 -112 C9 -112 17 -120 19.5 -134 L19.5 -126 C17 -114 9 -109 0 -109 C-9 -109 -17 -114 -19.5 -126 Z" fill="${C.hairL}" opacity=".5"/>
      <path d="M-14 -166 l3 -5 l3 5 M-6 -168 l3 -6 l3 6 M2 -168.5 l3 -6 l3 6 M10 -166 l3 -5 l2 5" fill="${C.hair}" stroke="${C.hair}" stroke-width="1.5" stroke-linejoin="round"/>
    </g>`;
  }

  // ---------------------------------------------------------------- tronco
  function torsoFront() {
    return `<g class="torso">
      <path d="M-24 -113 Q-24 -121 -14 -121 L14 -121 Q24 -121 24 -113 L26.5 -68 Q26.5 -60 18 -60 L-18 -60 Q-26.5 -60 -26.5 -68 Z" fill="${C.hood}"/>
      <path d="M-26.5 -66 L26.5 -66 L26 -68 Q26.5 -60 18 -60 L-18 -60 Q-26.5 -60 -26 -68 Z" fill="${C.hoodD}"/>
      <path d="M-15 -86 L15 -86 L19 -66 L-19 -66 Z" fill="${C.hoodD}" opacity=".55"/>
      <path d="M-9 -121 L0 -105 L9 -121 Z" fill="${C.skinD}"/>
      <path d="M-13 -122 Q0 -102 13 -122" stroke="${C.hoodD}" stroke-width="5" fill="none" stroke-linecap="round"/>
      <path d="M-4.5 -108 L-5 -88" stroke="${C.lime}" stroke-width="2" stroke-linecap="round"/>
      <path d="M4.5 -108 L5 -88" stroke="${C.lime}" stroke-width="2" stroke-linecap="round"/>
      <circle cx="-5" cy="-87" r="1.6" fill="${C.lime}"/><circle cx="5" cy="-87" r="1.6" fill="${C.lime}"/>
    </g>`;
  }
  function torsoBack() {
    return `<g class="torso">
      <path d="M-24 -113 Q-24 -121 -14 -121 L14 -121 Q24 -121 24 -113 L26.5 -68 Q26.5 -60 18 -60 L-18 -60 Q-26.5 -60 -26.5 -68 Z" fill="${C.hood}"/>
      <path d="M-26.5 -66 L26.5 -66 L26 -68 Q26.5 -60 18 -60 L-18 -60 Q-26.5 -60 -26 -68 Z" fill="${C.hoodD}"/>
      <path d="M-22 -119 Q0 -96 22 -119 L22 -110 Q0 -86 -22 -110 Z" fill="${C.hoodL}"/>
      <path d="M-22 -119 Q0 -96 22 -119" stroke="${C.hoodD}" stroke-width="1.5" fill="none"/>
      <path d="M0 -100 L0 -66" stroke="${C.hoodD}" stroke-width="1.4" opacity=".6"/>
    </g>`;
  }

  // ---------------------------------------------------------------- extremidades
  // arm: side -1 = izquierda de la pantalla. a/e en grados "hacia afuera" positivos.
  function arm(side, o = {}) {
    const sign = -side;
    const sx = side * 26, sy = -110;
    const a = o.a || 0, e = o.e || 0;
    const upperTf = o.animA ? '' : `transform="rotate(${f(sign * a)})"`;
    const foreTf = o.animE ? '' : `transform="rotate(${f(sign * e)})"`;
    const aAnim = o.animA ? anim(o.animA.split(';').map((v) => f(sign * v)).join(';'), o.dur || 2, o.kt) : '';
    const eAnim = o.animE ? anim(o.animE.split(';').map((v) => f(sign * v)).join(';'), o.dur || 2, o.kt) : '';
    const hold = o.hold || '';
    return `<g transform="translate(${sx} ${sy})"><g ${upperTf}>${aAnim}
      <rect x="-6.5" y="-5" width="13" height="29" rx="6.5" fill="${C.hood}"/>
      <g transform="translate(0 23)"><g ${foreTf}>${eAnim}
        <rect x="-6" y="-3" width="12" height="25" rx="6" fill="${C.hood}"/>
        <rect x="-6" y="16" width="12" height="5" rx="2" fill="${C.hoodD}"/>
        <circle cx="0" cy="26.5" r="5.4" fill="${C.skin}"/>${hold}
      </g></g></g></g>`;
  }
  // pierna rígida con zapatilla
  function leg(side, o = {}) {
    const hx = side * 9, hy = -64;
    const tf = o.anim ? '' : `transform="rotate(${f(o.a || 0)})"`;
    return `<g transform="translate(${hx} ${hy})"><g ${tf}>${o.anim ? anim(o.anim, o.dur || 1, o.kt) : ''}
      <rect x="-7.5" y="-3" width="15" height="62" rx="5" fill="${C.jeans}"/>
      <path d="M-1.5 6 L-1.5 40" stroke="${C.jeansL}" stroke-width="1.3" opacity=".8"/>
      <path d="M-8.5 55 L8.5 55 L10 62 Q10 66 6 66 L-9 66 Q-11.5 66 -11 62 Z" fill="${C.shoe}"/>
      <path d="M-11 62.5 L10.2 62.5 L10.2 64.5 Q10.2 66 8 66 L-9 66 Q-11.5 66 -11 64.5 Z" fill="${C.sole}"/>
      <path d="M-5 57 L5 57" stroke="${C.lime}" stroke-width="2" stroke-linecap="round"/>
    </g></g>`;
  }

  // ---------------------------------------------------------------- poses
  const dumbbell = '<g transform="translate(0 28)"><rect x="-10" y="-2.5" width="20" height="5" rx="2" fill="#8A94A3"/><rect x="-12" y="-7" width="5" height="14" rx="2" fill="#2A3140"/><rect x="7" y="-7" width="5" height="14" rx="2" fill="#2A3140"/></g>';

  function avatar(pose, opt = {}) {
    const P = pose || 'stand';
    let body = '';
    switch (P) {
      case 'walk': // de frente, balanceo de brazos y piernas
        body = `<g class="bob">
          ${leg(-1, { anim: '-20;20;-20', dur: 0.9 })}${leg(1, { anim: '20;-20;20', dur: 0.9 })}
          ${torsoFront()}
          ${arm(-1, { animA: '-26;26;-26', e: 0, dur: 0.9 })}${arm(1, { animA: '26;-26;26', e: 0, dur: 0.9 })}
          ${headFront({ mouth: opt.mouth })}</g>`;
        break;
      case 'lift': // curl con mancuernas alternado
        body = `<g class="breathe">
          ${leg(-1, { a: 2 })}${leg(1, { a: -2 })}
          ${torsoFront()}
          ${arm(-1, { a: 6, animE: '0;-140;-140;0;0', dur: 3.2, kt: '0;0.3;0.45;0.75;1', hold: dumbbell })}
          ${arm(1, { a: 6, animE: '0;0;-140;-140;0', dur: 3.2, kt: '0;0.3;0.55;0.8;1', hold: dumbbell })}
          ${headFront({ mouth: 'open' })}</g>`;
        break;
      case 'stretch': // despertar: estira los brazos
        body = `<g class="breathe">
          ${leg(-1, { a: 2 })}${leg(1, { a: -2 })}
          ${torsoFront()}
          ${arm(-1, { animA: '35;165;35', e: 0, dur: 3 })}${arm(1, { animA: '35;165;35', e: 0, dur: 3 })}
          ${headFront({ mouth: 'open', eyes: 'closed' })}</g>`;
        break;
      case 'sitBack': // de espaldas, sentado frente al escritorio (teclea)
        body = `<g class="breathe">
          ${torsoBack()}
          ${arm(-1, { a: 30, animE: '-86;-96;-86;-80;-86', dur: 0.7 })}
          ${arm(1, { a: 30, animE: '-86;-80;-86;-96;-86', dur: 0.8 })}
          ${headBack()}</g>`;
        break;
      case 'sitWrite': // de espaldas, escribe en clase (más lento)
        body = `<g class="breathe">
          ${torsoBack()}
          ${arm(-1, { a: 26, e: -84 })}
          ${arm(1, { a: 30, animE: '-90;-80;-90', dur: 1.6 })}
          ${headBack()}</g>`;
        break;
      case 'drive': // busto dentro del taxi, manos al volante
        body = `<g class="breathe">${torsoFront()}
          ${arm(-1, { a: -18, e: -52 })}${arm(1, { a: -18, e: -52 })}
          ${headFront({ look: 1 })}</g>`;
        break;
      case 'stand':
      default: // pose insignia: brazos cruzados
        body = `<g class="breathe">
          ${leg(-1, { a: 1.5 })}${leg(1, { a: -1.5 })}
          ${torsoFront()}
          ${arm(-1, { a: -8, e: -108 })}${arm(1, { a: -8, e: -112 })}
          ${headFront({ mouth: opt.mouth })}</g>`;
    }
    return `<g class="av av-${P}">${body}</g>`;
  }

  // Compañeros genéricos (para la clase): misma silueta, otra paleta, de espaldas
  function classmate(hair, top) {
    return `<g>
      <path d="M-24 -113 Q-24 -121 -14 -121 L14 -121 Q24 -121 24 -113 L26.5 -62 L-26.5 -62 Z" fill="${top}"/>
      <ellipse cx="-20.5" cy="-136" rx="4.2" ry="6" fill="#D9A47C"/><ellipse cx="20.5" cy="-136" rx="4.2" ry="6" fill="#D9A47C"/>
      <path d="M-19.5 -146 C-19.5 -165 19.5 -165 19.5 -146 L19.5 -129 C19.5 -116 9 -111 0 -111 C-9 -111 -19.5 -116 -19.5 -129 Z" fill="${hair}"/>
    </g>`;
  }

  window.Avatar = { avatar, headFront, torsoFront, arm, leg, classmate, C };
})();
