// Gemelo digital — vista Maqueta: diorama isométrico (CSS 3D) de toda tu vida a la vez.
// Casa, universidad, gym, calle con taxi y el distrito de proyectos. Se gira arrastrando.
(() => {
  const W = 1000, H = 620;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // ------------------------------------------------------------ color
  function shade(hex, k) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (k <= 1) { r *= k; g *= k; b *= k; } else { const t = k - 1; r += (255 - r) * t; g += (255 - g) * t; b += (255 - b) * t; }
    const h = (v) => Math.round(clamp(v, 0, 255)).toString(16).padStart(2, '0');
    return `#${h(r)}${h(g)}${h(b)}`;
  }

  // ------------------------------------------------------------ primitivas 3D
  function box(o) {
    const { x, y, w, d, h, z = 0 } = o;
    const ct = o.top, cf = o.front || shade(o.top, 0.8), cs = o.side || shade(o.top, 0.62);
    return `<div class="box ${o.cls || ''}" style="left:${x}px;top:${y}px;width:${w}px;height:${d}px;--d:${d}px;--h:${h}px;--ct:${ct};--cf:${cf};--cs:${cs};${z ? `transform:translateZ(${z}px);` : ''}${o.style || ''}"><i class="t"></i><i class="f"></i><i class="b"></i><i class="l"></i><i class="r"></i>${o.inner || ''}</div>`;
  }
  const flat = (x, y, w, d, bg, z = 0.6, extra = '') => `<div class="flat" style="left:${x}px;top:${y}px;width:${w}px;height:${d}px;background:${bg};transform:translateZ(${z}px);${extra}"></div>`;
  // cartel/sprite que mira siempre a la cámara, con los pies en (x,y,z)
  const bb = (x, y, z, html, cls = '', attrs = '') => `<div class="bb ${cls}" ${attrs} style="transform:translate3d(${x}px,${y}px,${z}px)"><div class="bbi">${html}</div></div>`;
  const group = (hot, label, inner, cls = '') => `<div class="grp mh ${cls}" data-hot="${hot}" aria-label="${esc(label)}">${inner}</div>`;

  // pared con hueco opcional (door = [desde, hasta] sobre el eje largo)
  function wallH(x, y, w, t, h, col, gap) {
    if (!gap) return box({ x, y, w, d: t, h, top: col });
    return box({ x, y, w: gap[0] - x, d: t, h, top: col }) + box({ x: gap[1], y, w: x + w - gap[1], d: t, h, top: col });
  }
  function wallV(x, y, t, d, h, col, gap) {
    if (!gap) return box({ x, y, w: t, d, h, top: col });
    return box({ x, y, w: t, d: gap[0] - y, h, top: col }) + box({ x, y: gap[1], w: t, d: y + d - gap[1], h, top: col });
  }
  function shell(x, y, w, d, col, doorSide, gap, wh = 22) {
    const t = 8;
    return wallH(x, y, w, t, wh, col, doorSide === 'n' ? gap : null) + wallH(x, y + d - t, w, t, wh, col, doorSide === 's' ? gap : null)
      + wallV(x, y, t, d, wh, col) + wallV(x + w - t, y, t, d, wh, col);
  }

  // ------------------------------------------------------------ geometría del mundo
  const AV_Y = 295;             // eje de la avenida
  const LOC = {                 // puertas, punto en la calle y lugar donde se queda
    casa: { door: [225, 232], road: [225, AV_Y], spot: [126, 208], name: 'Casa' },
    uni: { door: [760, 232], road: [760, AV_Y], spot: [717, 176], name: 'Universidad' },
    gym: { door: [225, 368], road: [225, AV_Y], spot: [150, 480], name: 'Gym' },
    calle: { door: [335, 290], road: [335, AV_Y], spot: [335, 290], name: 'Calle' },
  };
  const SPOT = {   // posiciones puntuales dentro de cada lugar según el estado
    dormir: ['casa', 118, 92], despertar: ['casa', 150, 120], codigo: ['casa', 126, 208], libre: ['casa', 300, 160], descanso: ['casa', 300, 160],
    clases: ['uni', 717, 176], estudio: ['uni', 872, 168], gym: ['gym', 150, 480],
  };
  const PARK = [335, 276];
  const LOOP = [[335, 276], [335, 312], [900, 312], [500, 312], [500, 70], [500, 312], [500, 560], [500, 312], [90, 312], [335, 312], [335, 276]];
  const PLACE = { dormir: 'casa', despertar: 'casa', libre: 'casa', descanso: 'casa', codigo: 'casa', estudio: 'uni', clases: 'uni', gym: 'gym', taxi: 'calle', camino: 'camino' };
  const TO_LOC = { casa: 'casa', uni: 'uni', gym: 'gym', taxi: 'calle' };
  const TOWER_AT = [[790, 392], [610, 392], [790, 482], [610, 482]];   // fondo-derecha, fondo-izquierda, frente-derecha, frente-izquierda
  const PROJ_COL = { finzo: '#6AD1FF', paso: '#B9F03C', lleva: '#FDCC0A', gemelo: '#C792EA' };

  function pathLen(pts) { let L = 0; for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); return L; }
  function along(pts, dist) {
    let d = dist;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]);
      if (d <= L || i === pts.length - 1) { const t = L ? clamp(d / L, 0, 1) : 0; return { x: a[0] + (b[0] - a[0]) * t, y: a[1] + (b[1] - a[1]) * t, hd: Math.atan2(b[1] - a[1], b[0] - a[0]) }; }
      d -= L;
    }
    return { x: pts[0][0], y: pts[0][1], hd: 0 };
  }
  // ruta a pie entre dos lugares pasando por puertas y avenida
  function route(from, to, spotTo, startPt) {
    const A = LOC[from], B = LOC[to]; const pts = [];
    pts.push(startPt || A.spot);
    if (from !== to) {
      if (from === 'transit' && Math.hypot(startPt[0] - B.door[0], startPt[1] - B.door[1]) < 70) { /* ya está en la puerta */ }
      else {
        if (from === 'transit') pts.push([clamp(startPt[0], 40, 960), AV_Y]); else { pts.push(A.door); pts.push(A.road); }
        pts.push(B.road); if (to !== 'calle') pts.push(B.door);
      }
    }
    pts.push(spotTo || B.spot);
    const out = [pts[0]]; for (let i = 1; i < pts.length; i++) if (Math.hypot(pts[i][0] - out[out.length - 1][0], pts[i][1] - out[out.length - 1][1]) > 0.5) out.push(pts[i]);
    return out;
  }

  // ------------------------------------------------------------ construcción de la maqueta
  const SKIN = '#C98B5E';
  function person(hair, top, pose) {  // figura genérica (profe / compañeros), de frente
    return `<svg viewBox="-34 -172 68 180" style="width:30px;height:80px"><g>
      <rect x="-22" y="-124" width="44" height="64" rx="12" fill="${top}"/><rect x="-14" y="-60" width="12" height="58" rx="5" fill="#222836"/><rect x="2" y="-60" width="12" height="58" rx="5" fill="#222836"/>
      <circle cx="0" cy="-140" r="20" fill="${SKIN}"/><path d="M-20 -142 Q-18 -164 0 -164 Q18 -164 20 -142 Q10 -152 0 -151 Q-10 -152 -20 -142Z" fill="${hair}"/>
      <circle cx="-7" cy="-139" r="2.2" fill="#2B1A14"/><circle cx="7" cy="-139" r="2.2" fill="#2B1A14"/>${pose || ''}</g></svg>`;
  }
  function backBust(hair, top) {
    return `<svg viewBox="-34 -172 68 120" style="width:34px;height:60px">${window.Avatar ? window.Avatar.classmate(hair, top) : ''}</svg>`;
  }

  function buildWorld(projects) {
    let h = '';
    // base y calles
    h += box({ x: 0, y: 0, w: W, d: H, h: 14, z: -14, top: '#1B2540', front: '#0F1526', side: '#0B1020' });
    h += flat(0, 0, W, H, 'linear-gradient(135deg,#1F2C48,#1A2640)', 0.2);
    h += flat(0, 260, W, 70, '#2A3042', 0.8) + flat(470, 0, 60, H, '#2A3042', 0.8);
    h += flat(0, AV_Y - 2, 470, 4, 'repeating-linear-gradient(90deg,#FDCC0A 0 16px,transparent 16px 34px)', 1.2, 'opacity:.75')
      + flat(530, AV_Y - 2, 470, 4, 'repeating-linear-gradient(90deg,#FDCC0A 0 16px,transparent 16px 34px)', 1.2, 'opacity:.75')
      + flat(498, 0, 4, 260, 'repeating-linear-gradient(180deg,#FDCC0A 0 16px,transparent 16px 34px)', 1.2, 'opacity:.75')
      + flat(498, 330, 4, 290, 'repeating-linear-gradient(180deg,#FDCC0A 0 16px,transparent 16px 34px)', 1.2, 'opacity:.75');
    // pasos de cebra en el cruce
    for (let i = 0; i < 6; i++) h += flat(474 + i * 9, 262, 5, 14, '#C9D1E3', 1.1, 'opacity:.55') + flat(474 + i * 9, 314, 5, 14, '#C9D1E3', 1.1, 'opacity:.55');
    // parcelas (veredas)
    h += flat(30, 30, 420, 215, '#26345A', 0.4, 'border-radius:14px') + flat(550, 20, 420, 225, '#2A3A5E', 0.4, 'border-radius:14px')
      + flat(30, 345, 420, 245, '#3A2C3F', 0.4, 'border-radius:14px') + flat(550, 345, 420, 245, '#22403A', 0.4, 'border-radius:14px');
    // caminitos a las puertas
    h += flat(205, 232, 40, 28, '#3A4363', 0.9) + flat(740, 232, 40, 28, '#3A4363', 0.9) + flat(205, 330, 40, 38, '#3A4363', 0.9);
    // bahía del taxi
    h += flat(300, 262, 72, 30, 'rgba(253,204,10,.10)', 1, 'border:2px solid rgba(253,204,10,.8);border-radius:6px');

    // ---------------- CASA
    const WC = '#8A94B2';
    let casa = box({ x: 60, y: 50, w: 170, d: 180, h: 3, top: '#5A4636' }) + box({ x: 230, y: 50, w: 170, d: 180, h: 3, top: '#394669' });
    casa += shell(60, 50, 340, 180, WC, 's', [200, 250]);
    casa += wallV(226, 58, 8, 164, 22, WC, [150, 190]);
    casa += flat(80, 175, 70, 40, '#2F3D63', 3.4, 'border-radius:8px');   // alfombra
    const bed = box({ x: 72, y: 62, w: 96, d: 58, h: 9, top: '#5B6BA3' }) + box({ x: 72, y: 64, w: 22, d: 54, h: 12, top: '#EEF2FA', style: '' })
      + box({ x: 96, y: 62, w: 72, d: 58, h: 13, top: '#2E3A66' });
    casa += group('place:casa', 'Casa', bed);
    const pc = box({ x: 80, y: 160, w: 96, d: 34, h: 16, top: '#7A5B3D' }) + box({ x: 116, y: 164, w: 34, d: 5, h: 20, z: 16, top: '#10131C', front: '#4DA3FF', side: '#10131C' }) + box({ x: 112, y: 176, w: 40, d: 10, h: 2, z: 16, top: '#D8DEEA' })
      + box({ x: 110, y: 198, w: 26, d: 20, h: 9, top: '#2B2F3C' });
    casa += group('pc', 'Computadora: mis proyectos', pc);
    casa += group('robot', 'Robot caminante', box({ x: 196, y: 66, w: 16, d: 16, h: 22, top: '#B9F03C' }) + box({ x: 198, y: 68, w: 12, d: 12, h: 8, z: 22, top: '#E2FF8A' }));
    casa += box({ x: 250, y: 66, w: 108, d: 36, h: 18, top: '#F2A65A' }) + box({ x: 250, y: 62, w: 108, d: 8, h: 30, top: '#D98A3C' })
      + box({ x: 278, y: 124, w: 56, d: 28, h: 8, top: '#8B6B4A' }) + box({ x: 366, y: 62, w: 24, d: 5, h: 34, top: '#10131C', front: '#6AD1FF' });
    h += group('place:casa', 'Casa', casa);

    // ---------------- UNIVERSIDAD
    const WU = '#7FA59B';
    let uni = box({ x: 570, y: 40, w: 226, d: 190, h: 3, top: '#53625F' }) + box({ x: 796, y: 40, w: 144, d: 190, h: 3, top: '#3F4F6A' });
    uni += shell(570, 40, 370, 190, WU, 's', [740, 780]);
    uni += wallV(792, 48, 8, 174, 22, WU, [150, 190]);
    uni += box({ x: 602, y: 46, w: 150, d: 4, h: 26, top: '#F4F6FA', front: '#E6EAF2' });                // pizarra
    uni += box({ x: 650, y: 66, w: 56, d: 22, h: 14, top: '#8B6B4A' });                                  // escritorio del profe
    const desks = [];
    for (let r = 0; r < 3; r++) for (let c = 0; c < 4; c++) desks.push([604 + c * 46, 104 + r * 40]);
    for (const [dx, dy] of desks) uni += box({ x: dx, y: dy, w: 32, d: 18, h: 9, top: '#C9B58A' });
    uni += box({ x: 826, y: 100, w: 84, d: 40, h: 11, top: '#9A7A55' });                                  // mesa de estudio
    uni += box({ x: 940 - 8 - 20, y: 56, w: 18, d: 120, h: 30, top: '#5E4A6B' });                        // estantes
    h += group('place:uni', 'Universidad', uni);

    // ---------------- GYM
    const WG = '#B48A93';
    let gym = box({ x: 60, y: 370, w: 340, d: 180, h: 3, top: '#2C303C' }) + flat(80, 436, 140, 90, '#3A4150', 3.4, 'border-radius:8px');
    gym += shell(60, 370, 340, 180, WG, 'n', [200, 250]);
    gym += group('weights', 'Rack de mancuernas', box({ x: 74, y: 524, w: 120, d: 16, h: 18, top: '#FF6B6B' }) + box({ x: 80, y: 508, w: 10, d: 10, h: 8, top: '#10131C' }) + box({ x: 96, y: 508, w: 10, d: 10, h: 8, top: '#10131C' }) + box({ x: 112, y: 508, w: 10, d: 10, h: 8, top: '#10131C' }));
    gym += box({ x: 110, y: 448, w: 72, d: 26, h: 10, top: '#4B5160' }) + box({ x: 106, y: 440, w: 80, d: 4, h: 16, top: '#8A94A3' });
    gym += box({ x: 300, y: 390, w: 38, d: 70, h: 14, top: '#3C4254' }) + box({ x: 350, y: 390, w: 38, d: 70, h: 14, top: '#3C4254' }) + box({ x: 304, y: 394, w: 30, d: 18, h: 3, z: 14, top: '#B9F03C' }) + box({ x: 354, y: 394, w: 30, d: 18, h: 3, z: 14, top: '#B9F03C' });
    gym += box({ x: 280, y: 520, w: 100, d: 12, h: 26, top: '#8EC3FF', front: '#A8D3FF', side: '#8EC3FF' });
    h += group('place:gym', 'Gym', gym);

    // ---------------- DISTRITO DE PROYECTOS
    h += flat(572, 365, 376, 200, '#18332D', 0.9, 'border-radius:10px;border:2px dashed rgba(185,240,60,.35)');
    for (let i = 0; i < projects.length; i++) {
      const p = projects[i], col = PROJ_COL[p.slug] || '#9AA5B1', [x, y] = TOWER_AT[i] || [592, 450];
      const t = box({ x, y, w: 64, d: 64, h: 40, top: col, cls: 'tower', style: `--h:${p.h || 40}px;` }) + box({ x: x + 10, y: y + 10, w: 44, d: 44, h: 6, z: 0, top: shade(col, 0.55), cls: 'plinth' });
      const flag = p.dirty > 0 ? box({ x: x + 50, y: y + 4, w: 5, d: 5, h: 22, z: p.h, top: '#6B4A32' }) + box({ x: x + 38, y: y + 4, w: 12, d: 4, h: 9, z: p.h + 22, top: '#FF9F43' }) : '';
      h += group(`proj:${p.slug}`, p.name, t + flag, 'tw');
    }
    // árboles de decoración
    for (const [tx, ty] of [[470 - 40, 40], [30, 250], [440, 320], [540, 335], [965, 255], [440, 590], [545, 595], [30, 600 - 20]]) {
      h += box({ x: tx, y: ty, w: 6, d: 6, h: 14, top: '#6B4A32' }) + box({ x: tx - 6, y: ty - 6, w: 18, d: 18, h: 16, z: 14, top: '#3FA66B', front: '#348F5B', side: '#2B7A4D' });
    }
    return h;
  }

  // ------------------------------------------------------------ montaje
  function mount(root, api) {
    const projects = [];
    const st = { rot: -38, tilt: 58, zoom: 1, ctx: null, projects, dragged: false, fit: 1, w: 0, h: 0 };
    // cuerpo del DOM
    root.innerHTML = `<div class="mq-sky"></div>
      <div class="mq-cam"><div class="mq-world" id="mqWorld"></div></div>
      <div class="mq-labels" id="mqLabels"></div>
      <div class="mq-ctl" role="group" aria-label="Cámara de la maqueta">
        <button type="button" data-v="iso" aria-pressed="true">Isométrica</button><button type="button" data-v="top">Desde arriba</button>
        <button type="button" data-v="in" aria-label="Acercar">+</button><button type="button" data-v="out" aria-label="Alejar">−</button>
      </div>
      <div class="mq-key"><span><i style="background:#B9F03C"></i>Altura de la torre = commits en 30 días</span><span><i style="background:#FF9F43"></i>Bandera = cambios sin commitear</span></div>`;
    const world = root.querySelector('#mqWorld'), labels = root.querySelector('#mqLabels');
    let tags = {}, anchors = {}, avEl, carEl, npc = [], zz;

    function projData() {
      const list = (api.getProjects() || []).filter((p) => PROJ_COL[p.slug]);
      const git = api.getGit();
      const rows = list.map((p) => {
        const g = git && git.repos && git.repos.find((r) => r.slug === p.slug && r.ok);
        const c30 = g && g.commits30d != null ? g.commits30d : (p.commits30d == null ? null : p.commits30d);
        const dirty = g ? g.dirtyFiles : p.uncommittedFiles;
        return { slug: p.slug, name: p.name, c30, dirty: dirty || 0, h: 38 + clamp(c30 || 0, 0, 30) * 5, live: !!g };
      });
      return rows.sort((x, y) => (y.c30 || 0) - (x.c30 || 0));
    }

    function build() {
      const pr = projData(); st.pdata = pr;
      const T = [
        { k: 'casa', hot: 'place:casa', x: 225, y: 50, z: 30, name: 'Casa' },
        { k: 'uni', hot: 'place:uni', x: 755, y: 40, z: 30, name: 'Universidad' },
        { k: 'gym', hot: 'place:gym', x: 150, y: 372, z: 40, name: 'Gym' },
        { k: 'calle', hot: 'taxi', x: 372, y: 262, z: 16, name: 'Taxi', cls: 'mini' },
        { k: 'proy', hot: 'place:proy', x: 575, y: 570, z: 12, name: 'Proyectos' },
        ...pr.map((p, i) => ({ k: `p-${p.slug}`, hot: `proj:${p.slug}`, x: TOWER_AT[i][0] + 32, y: TOWER_AT[i][1] + 32, z: p.h + 8, name: p.name, cls: 'mini tw', col: PROJ_COL[p.slug] })),
      ];
      labels.innerHTML = T.map((t) => `<button type="button" class="tag ${t.cls || ''}" data-hot="${t.hot}" data-k="${t.k}"${t.col ? ` style="--c:${t.col}"` : ''}><b>${esc(t.name)}</b><span></span></button>`).join('');
      anchors = {};
      world.innerHTML = buildWorld(pr)
        + T.map((t) => `<div class="anc" data-a="${t.k}" style="transform:translate3d(${t.x}px,${t.y}px,${t.z}px)"></div>`).join('')
        // personajes fijos
        + bb(666, 78, 14, person('#2B2321', '#7FC8B8'), 'npc t-profe', 'data-hot="teacher"')
        + [[620, 124, '#3A2E26', '#E26D5C'], [666, 124, '#1F1B1A', '#8E7CC3'], [620, 164, '#5A3A2A', '#E8B04B'], [758, 164, '#222', '#5DA9E9'], [712, 124, '#4A3322', '#F2A65A'], [758, 124, '#1F1B1A', '#6AD1FF']]
          .map(([x, y, hc, tc]) => bb(x + 16, y + 26, 10, backBust(hc, tc), 'npc')).join('')
        + bb(895, 200, 6, backBust('#2A2A2A', '#A8C7A0'), 'npc');
      // coche del taxi (3D) + coches decorativos
      world.insertAdjacentHTML('beforeend', `<div class="mv" id="mqCar" data-hot="taxi">${car('#FDCC0A', true)}</div><div class="mv" id="mqN1">${car('#8EA0C4')}</div><div class="mv" id="mqN2">${car('#C0586E')}</div>`);
      // Jherson (sprite) + z z z
      world.insertAdjacentHTML('beforeend', `<div class="bb av" id="mqAv" data-hot="avatar" style="transform:translate3d(126px,208px,4px)"><div class="bbi"><svg id="mqAvSvg" viewBox="-52 -172 104 182" style="width:40px;height:70px"></svg></div></div><div class="bb" id="mqZz" style="transform:translate3d(118px,70px,40px)"><div class="bbi zz">z<small>z</small>Z</div></div>`);
      avEl = world.querySelector('#mqAv'); carEl = world.querySelector('#mqCar'); npc = [world.querySelector('#mqN1'), world.querySelector('#mqN2')]; zz = world.querySelector('#mqZz');
      tags = {}; labels.querySelectorAll('.tag').forEach((t) => { tags[t.dataset.k] = t; }); world.querySelectorAll('.anc').forEach((a) => { anchors[a.dataset.a] = a; });
      poseKey = '';
      applyProjects();
    }
    function car(col, taxi) {
      let h = box({ x: -23, y: -12, w: 46, d: 24, h: 9, top: col, front: shade(col, 0.78), side: shade(col, 0.62) })
        + box({ x: -11, y: -10, w: 22, d: 20, h: 8, z: 9, top: 'rgba(200,226,255,.55)', front: 'rgba(170,205,240,.45)', side: 'rgba(150,190,230,.4)' });
      for (const sx of [-14, 8]) for (const sy of [-14, 11]) h += box({ x: sx, y: sy, w: 10, d: 3, h: 7, top: '#12151C' });
      if (taxi) h += box({ x: -3, y: -4, w: 9, d: 8, h: 4, z: 17, top: '#B9F03C' });
      return h;
    }
    function applyProjects() {
      (st.pdata || []).forEach((p) => {
        const tg = tags[`p-${p.slug}`]; if (!tg) return;
        const sp = tg.querySelector('span'); if (sp) sp.textContent = p.c30 == null ? 'sin repo' : `${p.c30} commits/30d`;
      });
    }

    // posiciona las etiquetas 2D sobre sus anclas 3D y evita que se pisen
    function placeLabels() {
      if (!st.w) return; const rr = root.getBoundingClientRect(); const placed = [];
      const order = Object.keys(tags).sort((a, b) => (a.startsWith('p-') ? 1 : 0) - (b.startsWith('p-') ? 1 : 0));
      for (const k of order) {
        const t = tags[k], an = anchors[k]; if (!an) continue;
        const r = an.getBoundingClientRect(); const w = t.offsetWidth, hh = t.offsetHeight;
        let x = clamp(r.left - rr.left, w / 2 + 6, st.w - w / 2 - 6), y = clamp(r.top - rr.top, hh + 6, st.h - 6);
        for (let n = 0; n < 5; n++) {
          const hit = placed.find((q) => Math.abs(q.x - x) < (q.w + w) / 2 + 4 && Math.abs(q.y - (y - hh / 2)) < (q.h + hh) / 2 + 4);
          if (!hit) break; y = hit.y - hit.h / 2 - 6;
        }
        y = Math.max(y, hh + 4);
        placed.push({ x, y: y - hh / 2, w, h: hh });
        t.style.transform = `translate(${(x - w / 2).toFixed(1)}px,${(y - hh).toFixed(1)}px)`;
      }
    }

    // ---------------- cámara
    function fitFor(rot, tilt) {
      const r = rot * Math.PI / 180, c = Math.cos(r), s = Math.sin(r), ct = Math.cos(tilt * Math.PI / 180), stl = Math.sin(tilt * Math.PI / 180);
      let mx = 0, my = 0;
      for (const [x, y] of [[-W / 2, -H / 2], [W / 2, -H / 2], [W / 2, H / 2], [-W / 2, H / 2]]) { mx = Math.max(mx, Math.abs(x * c - y * s)); my = Math.max(my, Math.abs((x * s + y * c) * ct)); }
      const bw = mx * 2 + 30, bh = my * 2 + 150 * stl + 40;
      return Math.min(st.w / bw, st.h / bh);
    }
    function cam() {
      const fit = fitFor(st.rot, st.tilt) * st.zoom;
      world.style.setProperty('--t', `${st.tilt}deg`); world.style.setProperty('--r', `${st.rot}deg`);
      world.style.setProperty('--rx', `${-st.tilt}deg`); world.style.setProperty('--rz', `${-st.rot}deg`);
      root.querySelector('.mq-cam').style.transform = `translate(-50%,-52%) scale(${fit})`;
      placeLabels();
    }
    let tw = null;
    function goView(rot, tilt, zoom) {
      cancelAnimationFrame(tw); const a = { rot: st.rot, tilt: st.tilt, zoom: st.zoom }, t0 = performance.now();
      let dr = rot - a.rot; dr = ((dr + 540) % 360) - 180;   // gira por el camino corto
      const step = (now) => { const k = clamp((now - t0) / 650, 0, 1), e = 1 - Math.pow(1 - k, 3); st.rot = a.rot + dr * e; st.tilt = a.tilt + (tilt - a.tilt) * e; st.zoom = a.zoom + (zoom - a.zoom) * e; cam(); if (k < 1) tw = requestAnimationFrame(step); };
      tw = requestAnimationFrame(step);
    }
    const ro = new ResizeObserver(() => { const b = root.getBoundingClientRect(); st.w = b.width; st.h = b.height; root.classList.toggle('narrow', st.w < 600); if (st.w) cam(); });
    ro.observe(root);

    // arrastrar para girar
    let drag = null;
    root.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('.mq-ctl')) return;
      drag = { x: e.clientX, y: e.clientY, rot: st.rot, tilt: st.tilt, moved: false }; st.dragged = false; cancelAnimationFrame(tw);
    });
    window.addEventListener('pointermove', (e) => {
      if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) > 6) { drag.moved = true; root.classList.add('grabbing'); }
      if (drag.moved) { st.dragged = true; st.rot = drag.rot + dx * 0.4; st.tilt = clamp(drag.tilt - dy * 0.3, 4, 82); cam(); setPressed(null); }
    });
    window.addEventListener('pointerup', () => { drag = null; root.classList.remove('grabbing'); });
    root.addEventListener('click', (e) => { if (st.dragged) { e.stopPropagation(); e.preventDefault(); st.dragged = false; } }, true);
    root.addEventListener('wheel', (e) => { e.preventDefault(); cancelAnimationFrame(tw); st.zoom = clamp(st.zoom * (e.deltaY < 0 ? 1.1 : 0.91), 0.5, 2.6); cam(); }, { passive: false });
    root.addEventListener('keydown', (e) => {
      if (e.target.closest('.tag') && !e.altKey) return;
      const k = e.key; if (k === 'ArrowLeft') st.rot -= 10; else if (k === 'ArrowRight') st.rot += 10; else if (k === 'ArrowUp') st.tilt = clamp(st.tilt + 5, 4, 82); else if (k === 'ArrowDown') st.tilt = clamp(st.tilt - 5, 4, 82); else if (k === '+' || k === '=') st.zoom = clamp(st.zoom * 1.1, 0.5, 2.6); else if (k === '-') st.zoom = clamp(st.zoom * 0.91, 0.5, 2.6); else return;
      e.preventDefault(); cam();
    });
    function setPressed(v) { root.querySelectorAll('.mq-ctl [data-v="iso"],.mq-ctl [data-v="top"]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.v === v))); }
    root.querySelector('.mq-ctl').addEventListener('click', (e) => {
      const b = e.target.closest('button'); if (!b) return; const v = b.dataset.v;
      if (v === 'iso') { goView(-38, 58, 1); setPressed('iso'); } else if (v === 'top') { goView(0, 12, 1); setPressed('top'); }
      else if (v === 'in') { st.zoom = clamp(st.zoom * 1.2, 0.5, 2.6); cam(); } else if (v === 'out') { st.zoom = clamp(st.zoom / 1.2, 0.5, 2.6); cam(); }
    });

    // ---------------- avatar y vehículos (bucle de animación)
    const av = { x: LOC.casa.spot[0], y: LOC.casa.spot[1], path: [], key: '', loc: 'casa', moving: false, aboard: false, prog: null };
    const car1 = { t: 0, on: false };
    let poseKey = '', last = performance.now(), run = false;
    const sprite = (pose, small) => `<svg id="mqAvSvg" viewBox="-52 -172 104 182" style="width:${small ? 30 : 40}px;height:${small ? 52 : 70}px">${window.Avatar.avatar(pose)}</svg>`;
    function setPose(pose, small) {
      const k = pose + (small ? 's' : ''); if (k === poseKey) return; poseKey = k;
      avEl.querySelector('.bbi').innerHTML = sprite(pose, small);
    }

    function desired() {
      const S = st.ctx && st.ctx.S; if (!S) return null;
      const c = S.current, state = c.state;
      if (state === 'camino') {
        const idx = S.day.findIndex((b) => b.start === c.start && b.state === 'camino');
        let prev = 'casa';
        for (let i = (idx < 0 ? S.day.length : idx) - 1; i >= 0; i--) { const pl = PLACE[S.day[i].state]; if (pl && pl !== 'camino') { prev = pl === 'calle' ? 'calle' : pl; break; } }
        const to = TO_LOC[c.to] || 'casa', from = prev;
        const span = Math.max(1, (c.end || c.start + 20) - c.start), prog = st.ctx.preview ? 0.5 : clamp(((S.lima.minutes + ((Date.now() / 1000) % 60) / 60) - c.start) / span, 0, 1);
        return { kind: 'camino', key: `camino:${from}>${to}:${c.start}`, from, to, prog };
      }
      if (state === 'taxi') return { kind: 'taxi', key: 'taxi' };
      const sp = SPOT[state] || SPOT.libre;
      return { kind: 'spot', key: `spot:${state}`, loc: sp[0], x: sp[1], y: sp[2], state };
    }

    function tick(now) {
      if (!run) return; const dt = Math.min(0.1, (now - last) / 1000); last = now;
      const D = desired();
      if (D) {
        // ----- avatar
        if (D.kind === 'taxi') {
          if (!av.aboard) {
            if (av.key !== 'toTaxi') { av.key = 'toTaxi'; av.path = route(av.loc === 'transit' ? 'transit' : av.loc, 'calle', PARK, [av.x, av.y]); av.moving = true; av.loc = 'transit'; }
            stepPath(dt, 230);
            if (!av.path.length) { av.aboard = true; av.loc = 'calle'; if (!car1.on) { car1.on = true; if (car1.t === 0) car1.t = ((Date.now() / 1000) % 60) * 0; } }
            // si la página se abre ya en turno de taxi y estamos lejos, sube directo
            if (!av.aboard && Math.hypot(av.x - PARK[0], av.y - PARK[1]) > 700) { av.x = PARK[0]; av.y = PARK[1]; }
          }
          if (av.aboard) { car1.on = true; }
        } else {
          av.aboard = false; car1.on = car1.on && car1.t > 0 && car1.t < carLen();
          if (D.kind === 'camino') {
            if (av.key !== D.key) { av.key = D.key; const fromSpot = D.from === 'calle' ? PARK : LOC[D.from].spot; av.route = route(D.from, D.to, D.to === 'calle' ? PARK : LOC[D.to].door, fromSpot); av.routeLen = pathLen(av.route); av.path = []; }
            const p = along(av.route, av.routeLen * D.prog); av.x += (p.x - av.x) * Math.min(1, dt * 4); av.y += (p.y - av.y) * Math.min(1, dt * 4); av.loc = 'transit'; av.moving = true;
          } else if (av.key !== D.key) {
            av.key = D.key; av.path = route(av.loc, D.loc, [D.x, D.y], [av.x, av.y]); av.moving = av.path.length > 1; av.loc = av.path.length > 1 ? 'transit' : D.loc; av.dest = D.loc;
          }
          if (D.kind === 'spot') { stepPath(dt, 200); if (!av.path.length) { av.loc = D.loc; av.moving = false; } }
        }
        // pose
        const dSleep = D.kind === 'spot' && D.state === 'dormir' && !av.moving;
        avEl.style.display = dSleep ? 'none' : ''; zz.style.display = dSleep ? '' : 'none';
        if (!dSleep) {
          if (D.kind === 'taxi' && av.aboard) setPose('drive', true);
          else if (av.moving || D.kind === 'camino') setPose('walk');
          else if (D.kind === 'spot') setPose(({ codigo: 'sitBack', clases: 'sitWrite', estudio: 'sitWrite', gym: 'lift', despertar: 'stretch' })[D.state] || 'stand');
          else setPose('stand');
        }
        // posición del avatar y del taxi
        if (D.kind === 'taxi' && av.aboard) { const c = along(LOOP, car1.t); av.x = c.x; av.y = c.y; }
        const lift = D.kind === 'taxi' && av.aboard ? 10 : D.kind === 'spot' && (D.state === 'codigo' || D.state === 'clases' || D.state === 'estudio') ? 4 : 4;
        avEl.style.transform = `translate3d(${av.x.toFixed(1)}px,${av.y.toFixed(1)}px,${lift}px)`;
      }
      // coche del taxi
      if (car1.on) { car1.t += 120 * dt; if (car1.t >= carLen()) { car1.t = 0; if (!(D && D.kind === 'taxi')) car1.on = false; } }
      const cp = car1.t > 0 ? along(LOOP, car1.t) : { x: PARK[0], y: PARK[1], hd: -Math.PI / 2 };
      carEl.style.transform = `translate3d(${cp.x.toFixed(1)}px,${cp.y.toFixed(1)}px,0) rotateZ(${(cp.hd * 180 / Math.PI).toFixed(1)}deg)`;
      // tráfico decorativo
      const t = now / 1000;
      npc[0].style.transform = `translate3d(${((t * 55) % 1100) - 50}px,276px,0)`;
      npc[1].style.transform = `translate3d(512px,${620 - ((t * 45 + 200) % 700) + 40}px,0) rotateZ(-90deg)`;
      requestAnimationFrame(tick);
    }
    const carLen = () => pathLen(LOOP);
    function stepPath(dt, speed) {
      let budget = speed * dt;
      while (av.path.length > 1 && budget > 0) {
        const a = av.path[0], b = av.path[1], L = Math.hypot(b[0] - av.x, b[1] - av.y);
        if (L <= budget) { av.x = b[0]; av.y = b[1]; budget -= L; av.path.shift(); }
        else { av.x += (b[0] - av.x) / L * budget; av.y += (b[1] - av.y) / L * budget; budget = 0; }
      }
      if (av.path.length === 1) { av.path = []; }
    }
    function start() { if (run) return; run = true; last = performance.now(); requestAnimationFrame(tick); }
    function stop() { run = false; }
    document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); else if (!root.hidden) start(); });

    // ---------------- actualización con el estado
    function update(ctx) {
      st.ctx = ctx; const S = ctx.S;
      const h = S.lima.minutes / 60, night = window.Scenes ? window.Scenes.night(h) : 0;
      world.style.setProperty('--nv', `${Math.round(night * 46)}%`);
      if (window.Scenes) { const [a, b] = window.Scenes.skyAt(h); root.style.setProperty('--sky1', a); root.style.setProperty('--sky2', b); }
      // dónde está
      const where = PLACE[S.current.state] || 'casa';
      for (const k of Object.keys(tags)) {
        const t = tags[k], span = t.querySelector('span'); if (!span) continue;
        t.classList.toggle('here', k === where || (k === 'calle' && where === 'camino'));
        if (k.startsWith('p-')) continue;
        span.textContent = tagText(k, ctx);
      }
      if (st.pdataSig !== JSON.stringify(projData().map((p) => [p.slug, p.h, p.dirty]))) { st.pdataSig = JSON.stringify(projData().map((p) => [p.slug, p.h, p.dirty])); build(); }
      for (const g of world.querySelectorAll('.grp')) g.classList.toggle('here', g.dataset.hot === `place:${where}`);
      placeLabels();
    }
    function tagText(k, ctx) {
      const S = ctx.S, META = ctx.META, c = S.current, min = S.lima.minutes;
      const place = PLACE[c.state];
      const mine = (b) => (k === 'calle' ? b.state === 'taxi' : PLACE[b.state] === k && b.state !== 'camino');
      if (k === 'proy') { const n = ctx.git && ctx.git.commitsToday; return n == null ? `${(st.pdata || []).length} proyectos` : `${n} commit${n === 1 ? '' : 's'} hoy`; }
      if ((k === place) || (k === 'calle' && place === 'camino')) {
        if (place === 'camino') return 'Pasando por aquí';
        return `Ahora · ${META[c.state].n}`;
      }
      const nxt = S.day.find((b) => mine(b) && b.start > min && !(k === 'casa' && (b.state === 'dormir')));
      if (nxt) return `Siguiente ${nxt.startHM}${nxt.course ? ' · ' + (nxt.code || nxt.course.split(' ')[0]) : ''}`;
      if (k === 'gym' && S.gym && S.gym.next) return `Próxima ${new Date(S.gym.next.date + 'T12:00:00Z').toLocaleDateString('es', { weekday: 'short', timeZone: 'UTC' })} ${S.gym.next.startHM}`;
      return ({ casa: 'Descanso', uni: 'Sin clases hoy', gym: 'Hoy no toca', calle: 'Sin turno hoy' })[k] || '—';
    }

    build(); cam(); setPressed('iso');
    return { update, start, stop, rebuild: build, cam, go: goView, resize: () => { const b = root.getBoundingClientRect(); st.w = b.width; st.h = b.height; root.classList.toggle('narrow', st.w < 600); cam(); } };
  }

  window.Maqueta = { mount };
})();
