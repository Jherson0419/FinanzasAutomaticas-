// Gemelo digital — interfaz: estado en vivo, escenas, línea de tiempo, paneles y diálogos.
(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const DAYS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const DAYS_S = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

  const META = {
    dormir: { n: 'Durmiendo', c: '#3B4E86' }, despertar: { n: 'Despertando', c: '#F2A65A' }, libre: { n: 'Tiempo libre', c: '#9AA5B1' },
    codigo: { n: 'Programando', c: '#B9F03C' }, estudio: { n: 'Estudiando', c: '#C792EA' }, gym: { n: 'En el gym', c: '#FF6B6B' },
    taxi: { n: 'Manejando el taxi', c: '#FDCC0A' }, camino: { n: 'En camino', c: '#6AD1FF' }, clases: { n: 'En clases', c: '#7FC8B8' },
    descanso: { n: 'Descansando', c: '#8FB3C8' },
  };
  const SHORT = { dormir: 'Dormir', despertar: 'Despertar', libre: 'Libre', codigo: 'Código', estudio: 'Estudio', gym: 'Gym', taxi: 'Taxi', camino: 'Camino', clases: 'Clases', descanso: 'Descanso' };

  let live = null, liveAt = 0, view = null, git = null, lastSig = '', hintGone = false, mode = 'escena', maq = null, projCache = null;

  // ------------------------------------------------------------ utilidades
  const post = (p, body) => fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Gemelo': '1' }, body: JSON.stringify(body || {}) }).then((r) => r.json());
  const del = (p) => fetch(p, { method: 'DELETE', headers: { 'X-Gemelo': '1' } }).then((r) => r.json());
  const get = (p) => fetch(p).then((r) => r.json());
  const cur = () => view || live;
  const nowMs = () => (view ? view.now : live ? live.now + (Date.now() - liveAt) : Date.now());
  const hm = (min) => `${String(Math.floor(min / 60) % 24).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
  const dur = (min) => { min = Math.max(0, Math.round(min)); const h = Math.floor(min / 60), m = min % 60; return h ? (m ? `${h} h ${m} min` : `${h} h`) : `${m} min`; };
  function limaClock() {
    const d = new Date(Date.now() - 5 * 3600e3);
    return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
  }
  const gitLast = () => {
    if (!git || !git.repos) return '';
    let best = null;
    for (const r of git.repos) if (r.ok && r.recent[0] && (!best || r.recent[0].ts > best.c.ts)) best = { r, c: r.recent[0] };
    return best ? `${best.r.name}: ${best.c.msg}` : '';
  };

  // ------------------------------------------------------------ dibujo
  function draw(S) {
    const svg = $('#svg');
    svg.innerHTML = Scenes.render(S.current.state, {
      h: S.lima.minutes / 60, minutes: S.lima.minutes, block: S.current, git: { last: gitLast() }, gymInfo: S.gym,
    });
    svg.classList.remove('in'); void svg.getBoundingClientRect(); svg.classList.add('in');
  }
  function render(force) {
    const S = cur(); if (!S) return;
    const sig = [S.current.state, S.current.label, S.current.course || '', S.current.to || '', Math.floor(S.lima.minutes / 20), S.gym.streak, gitLast(), mode].join('|');
    if (mode === 'maqueta') { if (maq) maq.update({ S, git, META, preview: !!view, getProjects: () => projCache }); lastSig = sig; }
    else if (force || sig !== lastSig) { lastSig = sig; draw(S); }
    chrome(S);
  }
  function chrome(S) {
    const m = META[S.current.state] || META.libre;
    $('#clock').textContent = limaClock();
    const chip = $('#stateChip');
    chip.innerHTML = `<i class="dot" style="background:${m.c}"></i><span>${esc(m.n)}${S.current.manual ? ' · manual' : ''}</span>`;
    // pie de escena
    const c = S.current;
    let title = m.n, sub = '';
    if (c.state === 'clases') { title = `${c.course}`; sub = `${c.kind || 'Clase'}${c.aula ? ' · Aula ' + c.aula : ''} · ${hm(c.start)}–${hm(c.end)}`; }
    else if (c.state === 'taxi') { title = c.label; sub = c.manual ? 'Estado manual' : `${hm(c.start)}–${hm(c.end)}`; }
    else if (c.state === 'camino') { title = c.label; sub = `${hm(c.start)}–${hm(c.end)}`; }
    else if (c.state === 'codigo') { title = 'Programando'; sub = `${c.label} · ${hm(c.start)}–${hm(c.end)}`; }
    else if (c.manual) { title = c.label; sub = 'Estado manual: pulsa "Cambiar estado" para volver al horario'; }
    else { title = c.label || m.n; sub = c.end ? `${hm(c.start)}–${c.end >= 1440 ? '24:00' : hm(c.end)}` : ''; }
    $('#caption').innerHTML = `<b>${esc(title)}</b><span>${esc(sub)}</span>`;
    // banner de vista previa
    const b = $('#banner');
    if (view) {
      const [y, mo, d] = view.lima.date.split('-').map(Number);
      b.hidden = false;
      b.innerHTML = `<span>Vista previa del horario: <b>${DAYS[view.lima.dow]} ${view.lima.hm}</b> (${String(d).padStart(2, '0')}/${String(mo).padStart(2, '0')}). No es tu estado actual.</span><button class="btn" id="backNow" type="button">Volver a ahora</button>`;
      $('#backNow').onclick = clearPreview;
    } else b.hidden = true;
    // chip de commits
    const chipC = $('#commitChip');
    if (git && git.configured && git.repos.some((r) => r.ok)) {
      chipC.hidden = false; chipC.textContent = `$ ${git.commitsToday} commit${git.commitsToday === 1 ? '' : 's'} hoy`;
    } else chipC.hidden = true;
    timeline(S);
  }
  function timeline(S) {
    const tl = $('#timeline');
    const min = S.lima.minutes;
    tl.innerHTML = S.day.map((b, i) => {
      const m = META[b.state] || META.libre;
      const isNow = min >= b.start && min < b.end && !S.current.manual;
      const label = b.state === 'clases' ? (b.course || '').split(' ').slice(0, 2).join(' ') : SHORT[b.state];
      return `<button class="seg ${b.end <= min ? 'past' : ''} ${isNow ? 'now' : ''}" type="button" data-i="${i}" style="--c:${m.c};--w:${b.end - b.start}" title="${esc(m.n)}${b.course ? ' · ' + esc(b.course) : ''} · ${b.startHM}–${b.endHM}">${(b.end - b.start) >= 100 ? esc(label) : ''}</button>`;
    }).join('') + `<div class="nowmark" style="left:calc(${(min / 1440) * 100}% - 1px)"></div>`;
    const tk = $('#timelineTicks') || (() => { const d = document.createElement('div'); d.id = 'timelineTicks'; d.className = 'ticks'; tl.after(d); return d; })();
    tk.innerHTML = [0, 3, 6, 9, 12, 15, 18, 21, 24].map((h) => `<span>${String(h).padStart(2, '0')}</span>`).join('');
    $('#legend').innerHTML = Object.entries(META).map(([k, v]) => `<span><i class="dot" style="background:${v.c}"></i>${esc(SHORT[k])}</span>`).join('');
  }
  $('#timeline').addEventListener('click', (e) => {
    const seg = e.target.closest('.seg'); if (!seg) return;
    const S = cur(); const b = S.day[Number(seg.dataset.i)];
    setPreview(S.lima.date, b.start);
  });

  // ------------------------------------------------------------ modo: escena / maqueta
  async function ensureProjects() { if (!projCache) { try { projCache = (await get('/api/projects')).projects || []; } catch { projCache = []; } } return projCache; }
  async function setMode(m, keep) {
    mode = m;
    if (!keep) { try { localStorage.setItem('gemelo.vista', m); } catch { /* sin almacenamiento */ } }
    const isM = m === 'maqueta';
    $('#svg').toggleAttribute('hidden', isM); $('#maq').toggleAttribute('hidden', !isM); $('#stage').classList.toggle('is-maq', isM);
    $('#vbEscena').setAttribute('aria-pressed', String(!isM)); $('#vbMaqueta').setAttribute('aria-pressed', String(isM));
    $('#vbNote').textContent = isM ? 'Todo a la vez: arrastra para girar, rueda para acercar' : 'Una escena a la vez, según lo que hago ahora';
    $('#hint').textContent = isM ? 'Arrastra para girar · toca un lugar' : 'Toca personajes y objetos';
    if (isM) {
      await ensureProjects();
      if (!maq) maq = Maqueta.mount($('#maq'), { getProjects: () => projCache, getGit: () => git });
      maq.start(); requestAnimationFrame(() => maq.resize());
    } else if (maq) maq.stop();
    lastSig = ''; render(true);
  }
  $('#vbEscena').onclick = () => setMode('escena');
  $('#vbMaqueta').onclick = () => setMode('maqueta');

  // ------------------------------------------------------------ vista previa
  async function setPreview(date, startMin) {
    view = await get(`/api/state?at=${date}T${hm(startMin)}`);
    $('#panel').hidden = true; render(true);
  }
  function clearPreview() { view = null; render(true); }

  // ------------------------------------------------------------ paneles
  const panel = $('#panel');
  function openPanel(html) { panel.innerHTML = `<button class="x" type="button" aria-label="Cerrar">×</button>${html}`; panel.hidden = false; panel.scrollTop = 0; $('.x', panel).onclick = () => (panel.hidden = true); }
  const kv = (k, v) => `<div class="kv"><span>${k}</span><span>${v}</span></div>`;
  const sec = (t, h) => `<div class="sec"><h3>${t}</h3>${h}</div>`;
  const dayName = (S, b) => (b.tomorrow ? 'mañana' : 'hoy');

  function panelAvatar() {
    const S = cur(), c = S.current, m = META[c.state] || META.libre;
    const elapsed = Math.max(0, Math.round((nowMs() - S.sinceMs) / 60000));
    const remaining = c.end ? c.end - S.lima.minutes : 0;
    const next = S.next;
    let h = `<h2>Jherson ${c.manual ? '<span class="badge">manual</span>' : ''}</h2>`;
    h += sec('Estado actual', `<div class="kv"><span><i class="dot" style="background:${m.c};margin-right:8px"></i>${esc(m.n)}</span><span>${view ? 'vista previa' : 'hace ' + dur(elapsed)}</span></div>
      ${c.course ? kv('Curso', esc(c.course)) : ''}${c.aula ? kv('Aula', esc(c.aula)) : ''}
      ${c.end && !c.manual ? kv('Termina', `${hm(c.end)} · en ${dur(remaining)}`) : ''}`);
    if (next) h += sec('Siguiente', kv(esc(next.label + (next.course ? ' · ' + next.course : '')), `${next.startHM} ${dayName(S, next)}`));
    // resumen del día (plan)
    const keys = ['clases', 'taxi', 'codigo', 'estudio', 'gym'].filter((k) => S.plannedMinutes[k]);
    const max = Math.max(...keys.map((k) => S.plannedMinutes[k]), 1);
    let sum = `<div class="bars">${keys.map((k) => `<div class="bar"><span>${esc(SHORT[k])}</span><i style="--c:${META[k].c};width:${(S.plannedMinutes[k] / max) * 100}%"></i><em>${dur(S.plannedMinutes[k])}</em></div>`).join('')}</div>`;
    if (!keys.length) sum = '<p class="note" style="margin:0">Sin bloques fijos este día.</p>';
    h += sec('Día en plan', sum + `<p class="note">Son horas <b>planeadas</b>, no medidas.${git && git.configured ? '' : ''}</p>`);
    if (git && git.repos && git.repos.some((r) => r.ok)) h += sec('Código real', kv('Commits hoy', `<b>${git.commitsToday}</b> (en tus repos)`));
    // gym
    const g = S.gym;
    h += sec('Gym', `<div class="kv"><span>Racha</span><span><span class="big" style="font-size:26px">${g.streak}</span> ${g.streak === 1 ? 'sesión' : 'sesiones'}</span></div>
      ${g.next ? kv('Próxima', `${DAYS_S[new Date(g.next.date + 'T12:00:00Z').getUTCDay()]} ${g.next.startHM}–${g.next.endHM}`) : ''}
      ${g.scheduledToday || g.doneToday ? `<div class="row"><button class="btn ${g.doneToday ? '' : 'primary'}" id="gymCheck" type="button">${g.doneToday ? 'Gym de hoy hecho · deshacer' : 'Marcar gym de hoy'}</button></div>` : `<p class="note">Hoy no toca gym. Tu horario de gym: lunes, jueves y sábado.</p>`}`);
    h += `<div class="row"><button class="btn primary" id="pOverride" type="button">Cambiar estado</button>${c.manual ? '<button class="btn danger" id="pClear" type="button">Volver al horario</button>' : ''}</div>`;
    h += `<p class="note">El horario muestra lo que debería pasar. El estado manual siempre gana y caduca solo.</p>`;
    openPanel(h);
    $('#pOverride').onclick = openOverride;
    if ($('#pClear')) $('#pClear').onclick = async () => { await del('/api/override'); panel.hidden = true; };
    if ($('#gymCheck')) $('#gymCheck').onclick = async () => { await post('/api/gym/checkin'); await refreshState(); panelAvatar(); };
  }
  // lugares de la maqueta
  const PLACES = {
    casa: { n: 'Casa', states: ['dormir', 'despertar', 'libre', 'descanso', 'codigo'], t: 'Mi cuarto y la sala. Aquí duermo, programo y descanso.' },
    uni: { n: 'Universidad', states: ['clases', 'estudio'], t: 'Clases, laboratorios y huecos de estudio en el campus.' },
    gym: { n: 'Gym', states: ['gym'], t: 'A 5 minutos de casa. Lunes, jueves y sábado.' },
    calle: { n: 'Calle · Taxi', states: ['taxi'], t: 'Mi trabajo: manejar el taxi por Trujillo.' },
  };
  function panelPlace(key) {
    if (key === 'proy') return panelProjects();
    const P = PLACES[key]; if (!P) return;
    const S = cur(), c = S.current, min = S.lima.minutes;
    const blocks = S.day.filter((b) => P.states.includes(b.state));
    const here = P.states.includes(c.state);
    const m = META[c.state] || META.libre;
    let h = `<h2>${esc(P.n)}</h2><p class="note" style="margin-top:6px">${esc(P.t)}</p>`;
    h += sec('Ahora', here ? kv(`<i class="dot" style="background:${m.c};margin-right:8px"></i>${esc(m.n)}`, c.manual ? 'manual' : (c.end ? 'hasta ' + hm(c.end) : '')) : `<p class="note" style="margin:0">No estoy aquí ahora.</p>`);
    h += sec('Hoy en este lugar', blocks.length ? `<ul class="list">${blocks.filter((b) => b.state !== 'dormir').map((b) => `<li>${esc((META[b.state] || META.libre).n)}${b.course ? ' · ' + esc(b.course) : ''}<small>${b.startHM}–${b.endHM}${b.end <= min ? ' · ya pasó' : (b.start <= min ? ' · ahora' : '')}</small></li>`).join('')}</ul>` : '<p class="note" style="margin:0">Hoy no hay nada planeado aquí.</p>');
    if (key === 'gym') { const g = S.gym; h += sec('Racha', `<div class="kv"><span>Sesiones seguidas</span><span><span class="big" style="font-size:26px">${g.streak}</span></span></div>${g.next ? kv('Próxima', `${DAYS_S[new Date(g.next.date + 'T12:00:00Z').getUTCDay()]} ${g.next.startHM}`) : ''}`); }
    if (key === 'calle') { const t = blocks.reduce((a, b) => a + (b.end - b.start), 0); if (t) h += kv('Total planeado hoy', dur(t)); }
    const first = blocks.find((b) => b.end > min && b.state !== 'dormir') || blocks.find((b) => b.state !== 'dormir');
    h += `<div class="row">${first ? '<button class="btn primary" id="seeScene" type="button">Ver esta escena</button>' : ''}${key === 'gym' ? `<button class="btn" id="gymCheck" type="button">${S.gym.doneToday ? 'Hoy hecho · deshacer' : 'Marcar gym de hoy'}</button>` : ''}${key === 'casa' ? '<button class="btn" id="goPc" type="button">Abrir la computadora</button>' : ''}</div>
      <p class="note">Horas planeadas, no medidas.</p>`;
    openPanel(h);
    if ($('#seeScene')) $('#seeScene').onclick = async () => { panel.hidden = true; await setMode('escena', true); setPreview(S.lima.date, first.start); };
    if ($('#gymCheck')) $('#gymCheck').onclick = async () => { await post('/api/gym/checkin'); await refreshState(); panelPlace('gym'); };
    if ($('#goPc')) $('#goPc').onclick = () => { panel.hidden = true; Computer.open(); };
  }
  function panelProjects() {
    const list = projCache || [];
    const g = (slug) => git && git.repos && git.repos.find((r) => r.slug === slug && r.ok);
    openPanel(`<h2>Distrito de proyectos</h2><p class="note" style="margin-top:6px">Cada torre es un proyecto. Su altura es la cantidad de commits de los últimos 30 días, y la bandera naranja avisa de cambios sin commitear.</p>
      ${sec('Proyectos', `<ul class="list">${list.map((p) => { const r = g(p.slug); const c30 = r && r.commits30d != null ? r.commits30d : p.commits30d; const dirty = r ? r.dirtyFiles : p.uncommittedFiles; return `<li><button class="plink" type="button" data-slug="${esc(p.slug)}">${esc(p.name)}</button><small>${esc(({ produccion: 'En producción', desarrollo: 'En desarrollo', prototipo: 'Prototipo' })[p.status] || p.status || '')} · ${c30 == null ? 'sin repositorio' : c30 + ' commits en 30 días'}${dirty ? ' · ' + dirty + ' sin commitear' : ''}${r ? ' · en vivo' : ' · dato guardado'}</small></li>`; }).join('')}</ul>`)}
      <div class="row"><button class="btn primary" id="goPc" type="button">Abrir la computadora</button></div>
      <p class="note">"En vivo" significa que leí el repositorio de tu computadora ahora; "dato guardado" es la última lectura.</p>`);
    $('#goPc').onclick = () => { panel.hidden = true; Computer.open(); };
    for (const b of panel.querySelectorAll('.plink')) b.onclick = () => { panel.hidden = true; Computer.open({ slug: b.dataset.slug }); };
  }
  function panelClass() {
    const S = cur(), c = S.current;
    if (c.state !== 'clases') {
      openPanel(`<h2>Hueco en el campus</h2><p class="note">Entre clases aprovecho para estudiar sin volver a casa.</p>${S.next ? sec('Siguiente', kv(esc(S.next.label + (S.next.course ? ' · ' + S.next.course : '')), S.next.startHM)) : ''}`);
      return;
    }
    const todays = S.day.filter((b) => b.state === 'clases');
    const idx = todays.findIndex((b) => b.start === c.start);
    openPanel(`<h2>${esc(c.course)}</h2>
      ${sec('Esta clase', kv('Código', esc(c.code)) + kv('Tipo', esc(c.kind || '')) + (c.aula ? kv('Aula', esc(c.aula)) : '') + kv('NRC', esc(c.nrc || '—')) + kv('Horario', `${hm(c.start)}–${hm(c.end)}`) + kv('Termina en', dur(c.end - S.lima.minutes)))}
      ${todays.length > 1 ? sec('Clases de hoy', `<ul class="list">${todays.map((b, i) => `<li>${esc(b.course)}<small>${esc(b.kind || '')} · ${hm(b.start)}–${hm(b.end)}${i === idx ? ' · ahora' : ''}</small></li>`).join('')}</ul>`) : ''}`);
  }
  function panelGym() {
    const S = cur(), g = S.gym;
    openPanel(`<h2>Pizarra del gym</h2>
      ${sec('Racha', `<div class="big">${g.streak}</div><p class="note" style="margin-top:6px">sesiones programadas seguidas. Total registradas: ${g.sessionsLogged}.</p>`)}
      ${sec('Plan', (g.next ? kv('Próxima sesión', `${DAYS_S[new Date(g.next.date + 'T12:00:00Z').getUTCDay()]} ${g.next.startHM}–${g.next.endHM}`) : '') + kv('Días de gym', 'Lun · Jue · Sáb') + kv('Empieza', esc(g.gymStart)))}
      <div class="row"><button class="btn ${g.doneToday ? '' : 'primary'}" id="gymCheck" type="button">${g.doneToday ? 'Hoy hecho · deshacer' : 'Marcar gym de hoy'}</button></div>
      <p class="note">Tú marcas la sesión; nada se detecta solo. Una sesión que no marques corta la racha.</p>`);
    $('#gymCheck').onclick = async () => { await post('/api/gym/checkin'); await refreshState(); panelGym(); };
  }
  function panelWeights() {
    openPanel(`<h2>Rack de mancuernas</h2><p class="note">Tu rutina y tus comidas viven en la app Paso. Ábrela en la computadora para ver sus pantallas (Rutina, Ejercicio, Hoy).</p><div class="row"><button class="btn primary" id="goPaso" type="button">Ver Paso en la computadora</button></div>`);
    $('#goPaso').onclick = () => { panel.hidden = true; Computer.open({ slug: 'paso', tab: 'interfaces' }); };
  }
  function panelTaxi() {
    const S = cur(); const turns = S.day.filter((b) => b.state === 'taxi');
    const total = turns.reduce((a, b) => a + (b.end - b.start), 0);
    openPanel(`<h2>Mi taxi</h2>
      ${sec('Turnos de hoy', turns.length ? `<ul class="list">${turns.map((b) => `<li>${esc(b.label)}<small>${b.startHM}–${b.endHM} · ${dur(b.end - b.start)}</small></li>`).join('')}</ul>` : '<p class="note" style="margin:0">Hoy no hay turno de taxi.</p>')}
      ${total ? kv('Total planeado', dur(total)) : ''}
      <p class="note">Taxi genérico, con la paleta de Lleva. Ahora no registra viajes ni ingresos.</p>`);
  }
  function panelSign() {
    const S = cur(), c = S.current;
    openPanel(`<h2>${esc(c.label)}</h2>${sec('Trayecto', kv('Salí', hm(c.start)) + kv('Llego', hm(c.end)) + kv('Faltan', dur(c.end - S.lima.minutes)))}`);
  }
  function panelClock() {
    const S = cur(), c = S.current;
    openPanel(`<h2>Reloj</h2>${sec('Ahora', kv('Hora en Trujillo', S.lima.hm) + (c.end ? kv('Esta clase termina', `${hm(c.end)} · en ${dur(c.end - S.lima.minutes)}`) : ''))}`);
  }
  function panelWindow() {
    const S = cur(), h = S.lima.minutes / 60;
    const fase = h < 5 ? 'Madrugada' : h < 7 ? 'Amanecer' : h < 12 ? 'Mañana' : h < 17.5 ? 'Tarde' : h < 19.8 ? 'Atardecer' : 'Noche';
    openPanel(`<h2>Ventana</h2>${sec('Afuera', kv('Hora en Trujillo', S.lima.hm) + kv('Momento del día', fase))}<p class="note">El cielo cambia con tu hora real. No usa datos del clima.</p>`);
  }
  function panelRobot() {
    openPanel(`<h2>Robot caminante</h2><p class="note">Proyecto de hobby: un robot pequeño que aprende a caminar y esquivar obstáculos entrenándose primero en simulación. Es una ficha manual: no está conectado a ninguna carpeta todavía.</p>`);
  }
  function panelPoster() {
    openPanel(`<h2>Un paso hoy. Otro mañana.</h2><p class="note">El lema de Paso, tu app de gym y comidas.</p><div class="row"><button class="btn primary" id="goPaso" type="button">Ver Paso en la computadora</button></div>`);
    $('#goPaso').onclick = () => { panel.hidden = true; Computer.open({ slug: 'paso' }); };
  }
  const QUIPS = ['¿Alguien tiene el PDF de la clase?', 'Profe, ¿esto entra en el examen?', '¿Ya subieron las notas?', 'Shhh, estoy copiando… apuntes.', 'Tengo sueño. Café, por favor.', '¿Hay laboratorio hoy?'];
  let toastT;
  function quip() {
    const t = $('#toast'); t.textContent = QUIPS[Math.floor(Math.random() * QUIPS.length)]; t.hidden = false;
    clearTimeout(toastT); toastT = setTimeout(() => (t.hidden = true), 2600);
  }

  // ------------------------------------------------------------ semana
  async function openWeek() {
    const w = await get('/api/week');
    const S = cur();
    const T0 = 5 * 60, T1 = 23 * 60 + 30, SPAN = T1 - T0, H = 540;
    let cols = '';
    for (const d of w.days) {
      const evs = d.blocks.filter((b) => !['dormir', 'despertar', 'libre'].includes(b.state)).map((b) => {
        const top = ((Math.max(b.start, T0) - T0) / SPAN) * 100, hh = ((Math.min(b.end, T1) - Math.max(b.start, T0)) / SPAN) * 100;
        if (hh <= 0) return '';
        const lab = b.state === 'clases' ? (b.course || '').replace(/ de .*$/, '').split(' ').slice(0, 2).join(' ') : SHORT[b.state];
        return `<button class="ev" type="button" data-date="${d.date}" data-start="${b.start}" style="--c:${META[b.state].c};top:${top}%;height:${hh}%" title="${esc(META[b.state].n)}${b.course ? ' · ' + esc(b.course) : ''} · ${b.startHM}–${b.endHM}">${hh > 3 ? esc(lab) : ''}</button>`;
      }).join('');
      cols += `<div class="col">${evs}</div>`;
    }
    const hours = []; for (let h = 6; h <= 23; h += 2) hours.push(`<span style="top:${((h * 60 - T0) / SPAN) * 100}%">${String(h).padStart(2, '0')}</span>`);
    const head = w.days.map((d) => `<div class="dayh ${d.isToday ? 'today' : ''}">${DAYS_S[d.dow]}</div>`).join('');
    overlay(`<div class="dialog" style="width:min(980px,100%)"><h2>Mi semana</h2><p>Toca un bloque para ver cómo se vería esa escena. Todo es plan, no registro.</p>
      <div class="week" style="margin-top:14px"><div></div>${head}<div class="hours">${hours.join('')}</div>${cols}</div>
      <div class="row"><button class="btn" id="closeDlg" type="button">Cerrar</button></div></div>`);
    $('#closeDlg').onclick = closeOverlay;
    for (const ev of document.querySelectorAll('.ev')) ev.onclick = () => { closeOverlay(); setPreview(ev.dataset.date, Number(ev.dataset.start)); };
  }

  // ------------------------------------------------------------ cambiar estado
  function openOverride() {
    const S = live || cur(); let pick = S.current.state;
    const states = ['codigo', 'clases', 'estudio', 'gym', 'taxi', 'camino', 'descanso', 'libre', 'dormir'];
    overlay(`<div class="dialog"><h2>Cambiar estado</h2><p>Lo que elijas gana sobre el horario hasta que caduque o lo quites.</p>
      <div class="statepick" role="group" aria-label="Estado">${states.map((k) => `<button type="button" data-k="${k}" aria-pressed="${k === pick}"><i class="dot" style="background:${META[k].c}"></i>${esc(META[k].n)}</button>`).join('')}</div>
      <div class="field"><label for="ovMin">Duración</label><select id="ovMin"><option value="30">30 minutos</option><option value="60" selected>1 hora</option><option value="120">2 horas</option><option value="240">4 horas</option><option value="480">8 horas</option></select></div>
      <div class="field"><label for="ovLabel">Nota</label><input id="ovLabel" maxlength="60" placeholder="opcional, ej. Entrega de Big Data"></div>
      <div class="row"><button class="btn primary" id="ovOk" type="button">Aplicar</button><button class="btn" id="ovCancel" type="button">Cancelar</button>${S.current.manual ? '<button class="btn danger" id="ovClear" type="button">Volver al horario</button>' : ''}</div></div>`);
    for (const b of document.querySelectorAll('.statepick button')) b.onclick = () => { pick = b.dataset.k; document.querySelectorAll('.statepick button').forEach((x) => x.setAttribute('aria-pressed', x === b)); };
    $('#ovCancel').onclick = closeOverlay;
    $('#ovOk').onclick = async () => { await post('/api/override', { state: pick, minutes: Number($('#ovMin').value), label: $('#ovLabel').value }); closeOverlay(); view = null; await refreshState(); panel.hidden = true; };
    if ($('#ovClear')) $('#ovClear').onclick = async () => { await del('/api/override'); closeOverlay(); await refreshState(); };
  }
  $('#btnOverride').onclick = openOverride;

  // ------------------------------------------------------------ overlay genérico
  const ov = $('#overlay');
  function overlay(html) { ov.innerHTML = html; ov.hidden = false; ov.onclick = (e) => { if (e.target === ov) closeOverlay(); }; }
  function closeOverlay() { ov.hidden = true; ov.innerHTML = ''; }
  window.addEventListener('keydown', (e) => { if (e.key === 'Escape') { if (!ov.hidden && !Computer.isOpen()) closeOverlay(); else if (!panel.hidden) panel.hidden = true; } });
  window.GemeloUI = { overlay, closeOverlay };

  // ------------------------------------------------------------ interacción con la escena
  const HOT = {
    avatar: panelAvatar, pc: () => Computer.open(), robot: panelRobot, window: panelWindow, calendar: openWeek, poster: panelPoster,
    teacher: panelClass, clock: panelClock, mate: quip, taxi: panelTaxi, sign: panelSign, weights: panelWeights,
    board: () => (cur().current.state === 'gym' ? panelGym() : panelClass()),
  };
  const stage = $('#stage');
  function activate(el) {
    const hot = el.closest && el.closest('[data-hot]'); if (!hot) return;
    const key = hot.dataset.hot;
    let fn = HOT[key];
    if (!fn && key.startsWith('place:')) fn = () => panelPlace(key.slice(6));
    if (!fn && key.startsWith('proj:')) fn = () => Computer.open({ slug: key.slice(5) });
    if (!fn) return;
    if (!hintGone) { hintGone = true; $('#hint').classList.add('gone'); }
    fn();
  }
  stage.addEventListener('click', (e) => activate(e.target));
  stage.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(e.target); } });
  $('#commitChip').onclick = () => {
    let best = null;
    for (const r of (git && git.repos) || []) if (r.ok && r.recent[0] && (!best || r.recent[0].ts > best.recent[0].ts)) best = r;
    Computer.open({ slug: best ? best.slug : undefined, tab: 'actividad' });
  };

  // ------------------------------------------------------------ datos en vivo
  async function refreshState() { live = await get('/api/state'); liveAt = Date.now(); if (!view) render(); }
  async function refreshGit() { try { git = await get('/api/git'); render(); } catch { /* sin git */ } }
  function connect() {
    try {
      const es = new EventSource('/api/events');
      es.onmessage = (e) => { live = JSON.parse(e.data); liveAt = Date.now(); if (!view) render(); };
      es.onerror = () => { /* el navegador reintenta; abajo hay sondeo de respaldo */ };
    } catch { /* sin SSE */ }
  }
  (async function init() {
    const q = new URLSearchParams(location.search);
    await refreshState();
    if (q.get('at')) { const [d, t] = q.get('at').split('T'); const [h, m] = t.split(':').map(Number); await setPreview(d, h * 60 + m); }
    render(true);
    let m0 = q.get('vista'); if (!m0) { try { m0 = localStorage.getItem('gemelo.vista'); } catch { /* nada */ } }
    if (m0 === 'maqueta') await setMode('maqueta', true);
    connect(); refreshGit();
    setInterval(() => { $('#clock').textContent = limaClock(); }, 1000);
    setInterval(() => { if (Date.now() - liveAt > 40000) refreshState().catch(() => {}); }, 20000);
    setInterval(refreshGit, 60000);
    setTimeout(() => { hintGone = true; $('#hint').classList.add('gone'); }, 9000);
    if (q.get('open')) { const [slug, tab] = q.get('open').split(':'); Computer.open({ slug, tab }); }
  })().catch((e) => { document.body.insertAdjacentHTML('beforeend', `<p style="padding:20px;color:#FF6B6B">No pude hablar con el servidor local: ${esc(e.message)}. ¿Está corriendo <code>node server.js</code>?</p>`); });
})();
