// Escenas vectoriales (viewBox 960x540). Cada escena devuelve markup SVG.
// Los objetos con data-hot="..." son interactivos (los maneja app.js).
(function () {
  const A = window.Avatar;
  const W = 960, H = 540;

  // ------------------------------------------------------------ utilidades de color / luz
  const hex = (c) => [1, 3, 5].map((i) => parseInt(c.slice(i, i + 2), 16));
  const mix = (a, b, t) => {
    const x = hex(a), y = hex(b);
    return '#' + x.map((v, i) => Math.round(v + (y[i] - v) * t).toString(16).padStart(2, '0')).join('');
  };
  // [hora, cielo arriba, cielo abajo]
  const SKY = [
    [0, '#0B1233', '#1C2A5C'], [5, '#10183F', '#2A3770'], [6, '#5B5E9C', '#F0A98C'], [7.2, '#7FB8F0', '#FCE1B5'],
    [10, '#7DC1FF', '#DDF1FF'], [16, '#7DC1FF', '#E6F2FF'], [17.6, '#F28E6A', '#FFD08A'], [18.8, '#5A4F96', '#E98A7C'],
    [19.8, '#141B45', '#33407A'], [24, '#0B1233', '#1C2A5C'],
  ];
  function skyAt(h) {
    for (let i = 0; i < SKY.length - 1; i++) {
      const [h0, t0, b0] = SKY[i], [h1, t1, b1] = SKY[i + 1];
      if (h >= h0 && h <= h1) { const t = (h - h0) / (h1 - h0); return [mix(t0, t1, t), mix(b0, b1, t)]; }
    }
    return [SKY[0][1], SKY[0][2]];
  }
  // 0 = pleno día, 1 = noche cerrada
  function night(h) {
    if (h >= 7.5 && h <= 17.5) return 0;
    if (h > 17.5 && h < 19.8) return (h - 17.5) / 2.3;
    if (h >= 19.8 || h <= 5) return 1;
    if (h > 5 && h < 7.5) return 1 - (h - 5) / 2.5;
    return 0;
  }
  // posición del sol (día) o luna (noche) sobre un arco dentro de un rectángulo
  function celestial(h, x, y, w, hh) {
    const day = h >= 6 && h < 18;
    const t = day ? (h - 6) / 12 : ((h >= 18 ? h - 18 : h + 6) / 12);
    return { day, cx: x + w * (0.12 + 0.76 * t), cy: y + hh * (0.78 - 0.62 * Math.sin(Math.PI * t)) };
  }
  const hot = (id, label, inner) =>
    `<g class="hot" data-hot="${id}" tabindex="0" role="button" aria-label="${label}">${inner}</g>`;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const clip = (s, n) => (s && s.length > n ? s.slice(0, n - 1) + '…' : s || '');

  function skyBlock(id, x, y, w, h, hour) {
    const [t, b] = skyAt(hour);
    const c = celestial(hour, x, y, w, h);
    const stars = night(hour) > 0.5
      ? Array.from({ length: 22 }, (_, i) => `<circle cx="${x + ((i * 53) % w)}" cy="${y + ((i * 37) % (h * 0.7))}" r="${i % 3 ? 1 : 1.6}" fill="#fff" opacity="${0.5 + (i % 4) * 0.12}"/>`).join('') : '';
    const body = c.day
      ? `<circle cx="${c.cx}" cy="${c.cy}" r="${Math.min(w, h) * 0.1}" fill="#FFE28A"/><circle cx="${c.cx}" cy="${c.cy}" r="${Math.min(w, h) * 0.16}" fill="#FFE28A" opacity=".25"/>`
      : `<circle cx="${c.cx}" cy="${c.cy}" r="${Math.min(w, h) * 0.08}" fill="#F4F1DD"/><circle cx="${c.cx + 5}" cy="${c.cy - 3}" r="${Math.min(w, h) * 0.07}" fill="${t}"/>`;
    return `<defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${t}"/><stop offset="1" stop-color="${b}"/></linearGradient>
      <clipPath id="${id}c"><rect x="${x}" y="${y}" width="${w}" height="${h}"/></clipPath></defs>
      <g clip-path="url(#${id}c)"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#${id})"/>${stars}${body}
      ${night(hour) < 0.6 ? `<g class="clouds" opacity=".9"><ellipse cx="${x + w * 0.3}" cy="${y + h * 0.3}" rx="30" ry="10" fill="#fff" opacity=".8"/><ellipse cx="${x + w * 0.42}" cy="${y + h * 0.26}" rx="22" ry="9" fill="#fff" opacity=".8"/></g>` : ''}</g>`;
  }

  // ============================================================ CASA
  function codeLines(git) {
    const cols = ['#B9F03C', '#6AD1FF', '#F2A65A', '#C792EA', '#9AA5B1', '#7EE787'];
    let y = 0, out = '';
    const widths = [60, 92, 40, 118, 74, 52, 104, 36, 88, 66, 130, 48, 96, 58, 110, 44];
    for (let i = 0; i < 16; i++) {
      const ind = [0, 14, 14, 28, 14, 0, 0, 14, 28, 28, 14, 0, 14, 14, 0, 0][i];
      out += `<rect x="${ind}" y="${y}" width="${widths[i]}" height="4.5" rx="2" fill="${cols[i % cols.length]}" opacity=".9"/>`;
      y += 9.5;
    }
    return `<g clip-path="url(#scrClip)"><g transform="translate(582 172)"><g class="codescroll">${out}<g transform="translate(0 152)">${out}</g></g></g></g>`;
  }

  function casa(ctx) {
    const { h: hour, state, git } = ctx;
    const asleep = state === 'dormir';
    const dark = asleep ? 0.62 : night(hour) * 0.46;
    const wallC = '#EBDFCD', floorC = '#C99D74';
    let s = `<defs><clipPath id="scrClip"><rect x="576" y="171" width="168" height="80"/></clipPath>
      <radialGradient id="lampG"><stop offset="0" stop-color="#FFE9A8" stop-opacity=".85"/><stop offset="1" stop-color="#FFE9A8" stop-opacity="0"/></radialGradient>
      <radialGradient id="monG"><stop offset="0" stop-color="#6AD1FF" stop-opacity=".5"/><stop offset="1" stop-color="#6AD1FF" stop-opacity="0"/></radialGradient></defs>`;
    // pared y piso
    s += `<rect width="${W}" height="400" fill="${wallC}"/><rect y="300" width="${W}" height="100" fill="#DCCBB3"/><rect y="296" width="${W}" height="6" fill="#C9B79C"/>
      <rect y="400" width="${W}" height="140" fill="${floorC}"/>`;
    for (let i = 0; i < 9; i++) s += `<path d="M0 ${410 + i * 16} H${W}" stroke="#B88B64" stroke-width="1.5" opacity=".55"/>`;
    s += `<ellipse cx="400" cy="500" rx="210" ry="30" fill="#2C3E63" opacity=".9"/><ellipse cx="400" cy="500" rx="190" ry="24" fill="none" stroke="#B9F03C" stroke-width="2" opacity=".8"/>`;

    // ventana (clicable)
    s += hot('window', 'Ventana: hora en Trujillo',
      `<rect x="62" y="52" width="226" height="206" rx="10" fill="#F7F2E9"/>${skyBlock('winSky', 76, 66, 198, 178, hour)}
       <path d="M175 66 V244 M76 155 H274" stroke="#F7F2E9" stroke-width="6"/>
       <path d="M50 52 q38 20 30 120 q-26 -4 -42 -8 Z" fill="#2C3E63"/><path d="M300 52 q-38 20 -30 120 q26 -4 42 -8 Z" fill="#2C3E63"/>`);

    // póster y calendario
    s += hot('poster', 'Póster: Un paso hoy',
      `<g transform="translate(486 60) scale(.78) translate(-500 -64)"><rect x="500" y="64" width="104" height="134" rx="5" fill="#15181E"/><rect x="508" y="72" width="88" height="118" rx="3" fill="#1E2A33"/>
       <path d="M516 168 h16 v-12 h16 v-12 h16 v-12 h16 v-12" stroke="#B9F03C" stroke-width="5" fill="none" stroke-linejoin="round"/>
       <text x="552" y="92" text-anchor="middle" font-size="11" font-weight="800" fill="#fff" font-family="Inter,system-ui">UN PASO</text>
       <text x="552" y="106" text-anchor="middle" font-size="11" font-weight="800" fill="#B9F03C" font-family="Inter,system-ui">HOY</text></g>`);
    s += hot('calendar', 'Horario semanal',
      `<g transform="translate(26 0)"><rect x="742" y="60" width="168" height="130" rx="8" fill="#fff"/><rect x="742" y="60" width="168" height="26" rx="8" fill="#2C3E63"/>
       <text x="826" y="78" text-anchor="middle" font-size="12" font-weight="800" fill="#fff" font-family="Inter,system-ui">MI SEMANA</text>
       ${['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => `<text x="${760 + i * 22}" y="104" font-size="10" font-weight="700" fill="#6B7280" text-anchor="middle" font-family="Inter,system-ui">${d}</text>`).join('')}
       ${[0, 1, 2, 3, 4, 5, 6].map((i) => `<rect x="${752 + i * 22}" y="112" width="16" height="12" rx="3" fill="${['#6AD1FF', '#B9F03C', '#6AD1FF', '#FDCC0A', '#B9F03C', '#FDCC0A', '#FDCC0A'][i]}"/>`).join('')}
       ${[0, 1, 2, 3, 4, 5, 6].map((i) => `<rect x="${752 + i * 22}" y="130" width="16" height="12" rx="3" fill="${['#B9F03C', '#6AD1FF', '#B9F03C', '#2C3E63', '#6AD1FF', '#B9F03C', '#2C3E63'][i]}" opacity=".85"/>`).join('')}
       <text x="826" y="170" text-anchor="middle" font-size="10" fill="#6B7280" font-family="Inter,system-ui">toca para ver la semana</text></g>`);

    // repisa + robot
    s += hot('robot', 'Robot caminante',
      `<rect x="318" y="196" width="150" height="9" rx="3" fill="#7A5A3E"/><path d="M332 205 v14 M454 205 v14" stroke="#5E4430" stroke-width="5"/>
       <rect x="336" y="150" width="9" height="46" fill="#2C3E63"/><rect x="346" y="160" width="8" height="36" fill="#B9F03C"/><rect x="355" y="154" width="9" height="42" fill="#F2A65A"/>
       <g transform="translate(410 196)"><g class="robot-bob">
        <rect x="-15" y="-44" width="30" height="24" rx="8" fill="#E9EEF3"/><rect x="-11" y="-40" width="22" height="14" rx="5" fill="#15181E"/>
        <circle cx="-5" cy="-33" r="2.6" fill="#B9F03C"/><circle cx="5" cy="-33" r="2.6" fill="#B9F03C"/>
        <path d="M0 -44 V-52" stroke="#9AA5B1" stroke-width="2"/><circle cx="0" cy="-54" r="3" fill="#F2A65A"/>
        <rect x="-12" y="-20" width="24" height="14" rx="5" fill="#B9F03C"/><rect x="-11" y="-6" width="8" height="8" rx="2" fill="#2C3E63"/><rect x="3" y="-6" width="8" height="8" rx="2" fill="#2C3E63"/></g></g>`);

    // cama
    s += `<g><ellipse cx="170" cy="478" rx="150" ry="14" fill="#000" opacity=".16"/>
      <rect x="24" y="336" width="18" height="144" rx="6" fill="#8B5E3C"/><rect x="40" y="440" width="258" height="22" rx="4" fill="#8B5E3C"/>
      <rect x="40" y="396" width="256" height="48" rx="12" fill="#F4F1EA"/>
      <ellipse cx="86" cy="394" rx="34" ry="14" fill="#FFFFFF"/></g>`;
    if (asleep) {
      s += hot('avatar', 'Jherson durmiendo',
        `<g transform="translate(88 455) scale(.52) rotate(-6)">${A.headFront({ eyes: 'closed' })}</g>
         <path d="M70 410 Q110 380 200 392 L300 396 L300 448 L70 448 Z" fill="#2C3E63"/><path d="M70 410 Q110 380 200 392" stroke="#B9F03C" stroke-width="4" fill="none"/>
         <g class="zzz" font-family="Inter,system-ui" font-weight="800" fill="#fff"><text x="120" y="360" font-size="22">Z</text><text x="146" y="334" font-size="17">z</text><text x="166" y="314" font-size="13">z</text></g>`);
    } else {
      s += `<path d="M90 408 Q140 392 296 398 L296 446 L90 446 Z" fill="#2C3E63"/><path d="M90 408 Q140 392 296 398" stroke="#B9F03C" stroke-width="4" fill="none"/>`;
    }
    // mesita + lámpara
    s += `<rect x="306" y="410" width="42" height="56" rx="4" fill="#8B5E3C"/><rect x="316" y="372" width="22" height="38" fill="#C9B79C"/><path d="M308 374 L346 374 L336 346 L318 346 Z" fill="#FDCC0A"/>`;

    // escritorio + PC
    s += `<rect x="476" y="372" width="404" height="14" rx="4" fill="#8B5E3C"/><rect x="492" y="386" width="10" height="92" fill="#6E4B30"/><rect x="852" y="386" width="10" height="92" fill="#6E4B30"/>
      <rect x="520" y="386" width="120" height="70" rx="4" fill="#7A5A3E"/><rect x="560" y="418" width="40" height="5" rx="2" fill="#C9B79C"/>`;
    s += hot('pc', 'Computadora con mis proyectos',
      `<rect x="568" y="150" width="184" height="134" rx="8" fill="#11141B"/><rect x="576" y="158" width="168" height="118" rx="4" fill="#0E1420"/>
       <rect x="576" y="158" width="168" height="12" rx="4" fill="#1B2436"/><circle cx="585" cy="164" r="2" fill="#FF6B6B"/><circle cx="593" cy="164" r="2" fill="#FDCC0A"/><circle cx="601" cy="164" r="2" fill="#B9F03C"/>
       ${codeLines(git)}
       <rect x="576" y="252" width="168" height="24" fill="#0A0F18"/><text x="582" y="262" font-size="7.5" fill="#B9F03C" font-family="ui-monospace,Menlo,Consolas,monospace">$ git log -1</text>
       <text x="582" y="271" font-size="7.5" fill="#9AA5B1" font-family="ui-monospace,Menlo,Consolas,monospace">${esc(clip(git && git.last ? git.last : 'toca para abrir mis proyectos', 34))}</text>
       <rect x="648" y="284" width="24" height="52" fill="#2A3140"/><rect x="622" y="334" width="76" height="8" rx="3" fill="#2A3140"/>
       <rect x="596" y="352" width="128" height="10" rx="4" fill="#2A3140"/>
       <rect x="598" y="354" width="124" height="3" fill="#3A4458"/>
       <rect x="744" y="356" width="14" height="9" rx="4" fill="#2A3140"/>`);
    // taza
    s += `<g transform="translate(800 356)"><rect x="-9" y="-14" width="18" height="16" rx="4" fill="#fff"/><path d="M9 -10 q8 2 0 8" stroke="#fff" stroke-width="3" fill="none"/><path class="steam" d="M-3 -18 q-4 -6 0 -10 M3 -18 q-4 -6 0 -10" stroke="#fff" stroke-width="2" fill="none" opacity=".7"/></g>`;

    // planta
    s += `<g transform="translate(920 470)"><path d="M-18 0 L-14 -34 H14 L18 0 Z" fill="#C0603E"/><path d="M0 -34 q-26 -30 -22 -62 q20 16 22 62 M0 -34 q24 -36 30 -58 q-26 8 -30 58 M0 -34 q-4 -44 6 -76 q10 36 -6 76" fill="#3E9B5C"/></g>`;

    // iluminación (antes del personaje, para no teñirlo)
    if (dark > 0.02) s += `<rect width="${W}" height="${H}" fill="#070B24" opacity="${dark}" pointer-events="none"/>`;
    if (dark > 0.15 && !asleep) s += `<circle cx="327" cy="352" r="130" fill="url(#lampG)" pointer-events="none"/>`;
    if (state === 'codigo' && dark > 0.1) s += `<ellipse cx="660" cy="250" rx="170" ry="120" fill="url(#monG)" opacity=".55" pointer-events="none"/>`;

    // personaje (más oscuro de noche)
    const br = (1 - dark * 0.7).toFixed(2);
    if (state === 'codigo') {
      s += `<rect x="578" y="388" width="84" height="62" rx="14" fill="#2A3550"/><rect x="604" y="448" width="32" height="22" fill="#1B2436"/><ellipse cx="620" cy="478" rx="36" ry="8" fill="#1B2436"/>`;
      s += hot('avatar', 'Jherson programando',
        `<g transform="translate(620 482) scale(1.12)" style="filter:brightness(${br})">${A.avatar('sitBack')}<rect x="-40" y="-176" width="80" height="120" fill="transparent"/></g>`);
    } else if (!asleep) {
      const pose = state === 'despertar' ? 'stretch' : 'stand';
      s += `<ellipse cx="400" cy="486" rx="40" ry="8" fill="#000" opacity=".22"/>`;
      s += hot('avatar', 'Jherson', `<g transform="translate(400 482) scale(1.2)" style="filter:brightness(${br})">${A.avatar(pose)}<rect x="-40" y="-176" width="80" height="180" fill="transparent"/></g>`);
    }
    return s;
  }

  // ============================================================ UNIVERSIDAD
  function teacher() {
    return `<g class="sway"><ellipse cx="0" cy="2" rx="30" ry="6" fill="#000" opacity=".2"/>
      <rect x="-12" y="-62" width="9" height="62" rx="3" fill="#33384A"/><rect x="3" y="-62" width="9" height="62" rx="3" fill="#33384A"/>
      <rect x="-14" y="-6" width="12" height="6" rx="2" fill="#15181E"/><rect x="2" y="-6" width="12" height="6" rx="2" fill="#15181E"/>
      <path d="M-22 -112 Q-22 -120 -12 -120 L12 -120 Q22 -120 22 -112 L24 -60 L-24 -60 Z" fill="#5A4A7A"/><path d="M-6 -120 L0 -90 L6 -120 Z" fill="#fff"/>
      <rect x="-26" y="-108" width="9" height="44" rx="4" fill="#5A4A7A"/><rect x="17" y="-108" width="9" height="44" rx="4" fill="#5A4A7A"/>
      <circle cx="-21" cy="-62" r="5" fill="#E0B08C"/><circle cx="21" cy="-62" r="5" fill="#E0B08C"/>
      <rect x="-6" y="-128" width="12" height="9" fill="#C99872"/>
      <ellipse cx="0" cy="-142" rx="17" ry="20" fill="#E0B08C"/><path d="M-17 -146 Q-16 -164 0 -163 Q16 -164 17 -146 Q10 -156 0 -155 Q-10 -156 -17 -146 Z" fill="#8E8E96"/>
      <circle cx="-6.5" cy="-142" r="2" fill="#2B1A14"/><circle cx="6.5" cy="-142" r="2" fill="#2B1A14"/>
      <circle cx="-6.5" cy="-142" r="6" fill="none" stroke="#2B2B33" stroke-width="1.6"/><circle cx="6.5" cy="-142" r="6" fill="none" stroke="#2B2B33" stroke-width="1.6"/><path d="M-0.5 -142 h1" stroke="#2B2B33" stroke-width="1.6"/>
      <path d="M-5 -131 Q0 -128 5 -131" stroke="#7A3B2A" stroke-width="1.6" fill="none" stroke-linecap="round"/>
      <path d="M26 -72 L58 -122" stroke="#C9B79C" stroke-width="3" stroke-linecap="round"/></g>`;
  }
  function desk(x, y, w) {
    return `<rect x="${x}" y="${y}" width="${w}" height="16" rx="4" fill="#B98B5E"/><rect x="${x + 6}" y="${y + 16}" width="${w - 12}" height="8" fill="#8B5E3C" opacity=".7"/>`;
  }
  function uni(ctx) {
    const { h: hour, state, block } = ctx;
    const study = state === 'estudio';
    const dark = night(hour) * 0.3;
    let s = `<rect width="${W}" height="372" fill="#DCE6EE"/><rect y="296" width="${W}" height="6" fill="#BFCCD8"/><rect y="372" width="${W}" height="168" fill="#C7B496"/>`;
    for (let i = 0; i < 9; i++) s += `<path d="M0 ${382 + i * 18} H${W}" stroke="#B5A183" stroke-width="1.4" opacity=".6"/>`;
    // ventana a la derecha
    s += `<rect x="770" y="90" width="170" height="190" rx="8" fill="#F7F2E9"/>${skyBlock('uniSky', 782, 102, 146, 166, hour)}<path d="M855 102 V268 M782 185 H928" stroke="#F7F2E9" stroke-width="6"/>`;
    // pizarra
    const t1 = study ? 'Hueco entre clases' : (block && block.code) || 'Clase';
    const t2 = study ? 'Aprovecho para estudiar en el campus' : (block && block.course) || '';
    const t3 = study ? '' : [block && block.kind, block && block.aula ? 'Aula ' + block.aula : ''].filter(Boolean).join(' · ');
    s += hot('board', 'Pizarra del curso',
      `<rect x="98" y="46" width="562" height="214" rx="8" fill="#8B5E3C"/><rect x="108" y="56" width="542" height="194" rx="4" fill="#244A42"/>
       <rect x="98" y="256" width="562" height="8" fill="#6E4B30"/>
       <text x="130" y="108" font-size="26" font-weight="800" fill="#EAF7EF" font-family="'Segoe Print','Comic Sans MS',cursive,sans-serif">${esc(t1)}</text>
       <text x="130" y="148" font-size="${t2.length > 30 ? 20 : 24}" fill="#EAF7EF" font-family="'Segoe Print','Comic Sans MS',cursive,sans-serif">${esc(clip(t2, 40))}</text>
       <text x="130" y="188" font-size="19" fill="#B9F03C" font-family="'Segoe Print','Comic Sans MS',cursive,sans-serif">${esc(t3)}</text>
       <path d="M130 212 q40 -12 80 0 t80 0 t80 0" stroke="#EAF7EF" stroke-width="2" fill="none" opacity=".5"/>`);
    // reloj
    const mm = ctx.minutes % 60, hh = (ctx.minutes / 60) % 12;
    s += hot('clock', 'Reloj del aula',
      `<circle cx="708" cy="92" r="26" fill="#fff" stroke="#2C3E63" stroke-width="4"/>
       <path d="M708 92 L${708 + 12 * Math.sin((hh / 12) * 2 * Math.PI)} ${92 - 12 * Math.cos((hh / 12) * 2 * Math.PI)}" stroke="#2C3E63" stroke-width="3" stroke-linecap="round"/>
       <path d="M708 92 L${708 + 19 * Math.sin((mm / 60) * 2 * Math.PI)} ${92 - 19 * Math.cos((mm / 60) * 2 * Math.PI)}" stroke="#2C3E63" stroke-width="2" stroke-linecap="round"/>`);
    if (!study) s += hot('teacher', 'Profesor', `<g transform="translate(700 322)">${teacher()}<rect x="-30" y="-170" width="90" height="176" fill="transparent"/></g>`);

    // fila A (lejos)
    const mates = [['#6B3E26', '#E3F1E1'], ['#C98A2B', '#C94F7C'], ['#1E1E24', '#5A7DB8'], ['#7A4A2A', '#F2C46D']];
    const rowA = [[190, 0], [340, 1], [610, 2]];
    for (const [x, i] of rowA) {
      s += desk(x - 70, 340, 140);
      s += hot('mate', 'Compañero', `<g transform="translate(${x} 410) scale(.8)">${A.classmate(mates[i][0], mates[i][1])}<rect x="-30" y="-170" width="60" height="120" fill="transparent"/></g>`);
    }
    // fila B (cerca)
    s += desk(130, 420, 150) + desk(400, 410, 170) + desk(690, 420, 150);
    s += hot('mate', 'Compañero', `<g transform="translate(205 505)">${A.classmate(mates[3][0], mates[3][1])}<rect x="-30" y="-170" width="60" height="120" fill="transparent"/></g>`);
    s += hot('mate', 'Compañero', `<g transform="translate(765 505)">${A.classmate(mates[0][0], mates[0][1])}<rect x="-30" y="-170" width="60" height="120" fill="transparent"/></g>`);
    if (study) {
      s += `<rect x="440" y="396" width="90" height="12" rx="3" fill="#E5E7EB"/><path d="M448 396 L458 372 H512 L522 396 Z" fill="#9AA5B1"/><rect x="462" y="376" width="46" height="16" rx="2" fill="#6AD1FF"/>`;
    } else {
      s += `<rect x="452" y="400" width="52" height="10" rx="2" fill="#fff"/><rect x="456" y="396" width="44" height="6" rx="2" fill="#F2A65A"/>`;
    }
    s += hot('avatar', 'Jherson en clase',
      `<g transform="translate(485 505)">${A.avatar(study ? 'sitBack' : 'sitWrite')}<rect x="-40" y="-176" width="80" height="120" fill="transparent"/></g>`);
    if (dark > 0.02) s += `<rect width="${W}" height="${H}" fill="#070B24" opacity="${dark}" pointer-events="none"/>`;
    return s;
  }

  // ============================================================ CALLE (taxi y caminata)
  const BLD = [
    [0, 130, 190, '#F2C46D', '#C98A2B'], [140, 110, 150, '#7FC8B8', '#3E9B8C'], [260, 150, 215, '#E8908A', '#B85E58'],
    [420, 100, 160, '#F5E6C8', '#CDB98F'], [530, 140, 200, '#9DB7E0', '#5F7FB6'], [680, 120, 170, '#F2C46D', '#C98A2B'],
    [810, 150, 205, '#B7D9A5', '#6FA25A'],
  ];
  function buildings(offset, hour) {
    const dk = night(hour);
    let s = '';
    for (const [x, w, h, c, d] of BLD) {
      const bx = x + offset, top = 392 - h, col = mix(c, '#1A2040', dk * 0.55), dcol = mix(d, '#1A2040', dk * 0.55);
      s += `<rect x="${bx}" y="${top}" width="${w}" height="${h}" fill="${col}"/><rect x="${bx}" y="${top}" width="${w}" height="10" fill="${dcol}"/><rect x="${bx}" y="${380}" width="${w}" height="12" fill="${dcol}" opacity=".7"/>`;
      const cols = Math.max(2, Math.floor(w / 42));
      for (let r = 0; r < Math.floor((h - 70) / 62) + 1; r++) {
        for (let k = 0; k < cols; k++) {
          const wx = bx + 12 + k * ((w - 24) / cols), wy = top + 28 + r * 62;
          const lit = dk > 0.4 && (k + r + x) % 3 !== 0;
          s += `<path d="M${wx} ${wy + 34} V${wy + 10} a10 10 0 0 1 20 0 V${wy + 34} Z" fill="${lit ? '#FFD87A' : mix('#2C3E63', '#9DB7E0', 0.15 + (1 - dk) * 0.25)}"/>`;
        }
        s += `<rect x="${bx + 6}" y="${top + 28 + r * 62 + 34}" width="${w - 12}" height="4" fill="${dcol}" opacity=".6"/>`;
      }
    }
    return s;
  }
  function lampPosts(offset, hour) {
    const lit = night(hour) > 0.4;
    return [60, 340, 620, 900].map((x) => `<g transform="translate(${x + offset} 392)"><rect x="-2" y="-120" width="4" height="120" fill="#2A3140"/><rect x="-10" y="-126" width="20" height="8" rx="3" fill="#2A3140"/>${lit ? '<circle cx="0" cy="-116" r="26" fill="#FFE9A8" opacity=".35"/>' : ''}</g>`).join('');
  }
  function taxiCar(hour) {
    const n = night(hour);
    return `<g class="car-bounce">
      <ellipse cx="0" cy="62" rx="150" ry="10" fill="#000" opacity=".28"/>
      <path d="M-150 30 Q-150 12 -128 10 L-92 6 Q-70 -34 -26 -38 L58 -38 Q94 -36 116 4 L140 10 Q152 14 152 30 L152 52 L-150 52 Z" fill="#1B3558"/>
      <rect x="-150" y="38" width="302" height="8" fill="#FDCC0A"/>
      <path d="M-84 6 Q-64 -26 -26 -30 L-6 -30 L-6 6 Z" fill="#CFE6F7"/><path d="M6 -30 L56 -30 Q88 -28 104 4 L6 4 Z" fill="#CFE6F7"/>
      <path d="M-6 -30 V6" stroke="#1B3558" stroke-width="6"/>
      <rect x="-30" y="-52" width="60" height="16" rx="4" fill="#FDCC0A"/><text x="0" y="-40" text-anchor="middle" font-size="11" font-weight="900" fill="#1B3558" font-family="Inter,system-ui">TAXI</text>
      <rect x="-30" y="-38" width="60" height="3" fill="#1B3558"/>
      <rect x="142" y="16" width="10" height="10" rx="3" fill="${n > 0.4 ? '#FFF6B0' : '#FFFBE0'}"/><rect x="-152" y="16" width="8" height="10" rx="3" fill="#E5484D"/>
      ${n > 0.4 ? '<path d="M152 18 L300 -6 L300 52 Z" fill="#FFF6B0" opacity=".28"/>' : ''}
      <rect x="-24" y="22" width="22" height="5" rx="2" fill="#10213A"/><rect x="40" y="22" width="22" height="5" rx="2" fill="#10213A"/>
      ${[-92, 92].map((wx) => `<g transform="translate(${wx} 52)"><circle r="23" fill="#15181E"/><circle r="13" fill="#B7BDC8"/><g><animateTransform attributeName="transform" type="rotate" values="0;360" dur="0.55s" repeatCount="indefinite"/><path d="M-12 0 H12 M0 -12 V12" stroke="#6B7280" stroke-width="3"/></g><circle r="3" fill="#15181E"/></g>`).join('')}
    </g>`;
  }
  const DEST = { uni: 'Universidad', casa: 'Casa', taxi: 'Taxi', gym: 'Gym' };
  function calle(ctx) {
    const { h: hour, state, block } = ctx;
    const driving = state === 'taxi';
    const dur = driving ? 14 : 36;
    const dk = night(hour);
    let s = skyBlock('stSky', 0, 0, W, 330, hour).replace('<g clip-path', '<g clip-path');
    s += `<path d="M0 330 Q120 250 260 300 T520 290 T780 300 T960 270 V392 H0 Z" fill="${mix('#7C93B8', '#141B45', dk * 0.8)}" opacity=".7"/>`;
    s += `<g class="slide" style="animation-duration:${dur * 1.6}s"><g>${buildings(0, hour)}</g><g>${buildings(960, hour)}</g></g>`;
    s += `<rect y="392" width="${W}" height="24" fill="${mix('#BDB5A6', '#2B2F44', dk * 0.6)}"/><rect y="416" width="${W}" height="124" fill="${mix('#3F4553', '#171A26', dk * 0.5)}"/><rect y="410" width="${W}" height="8" fill="${mix('#A39B8C', '#2B2F44', dk * 0.6)}"/>`;
    s += `<g class="slide" style="animation-duration:${dur}s"><g>${lampPosts(0, hour)}</g><g>${lampPosts(960, hour)}</g></g>`;
    s += `<g class="slide-fast" style="animation-duration:${driving ? 1.4 : 5}s"><path d="M0 500 H1920" stroke="#F5E58A" stroke-width="6" stroke-dasharray="60 50" opacity=".85"/></g>`;
    if (driving) {
      s += hot('taxi', 'Mi taxi',
        `<g transform="translate(470 440)">${taxiCar(hour)}
          <g clip-path="url(#winClip)"><defs><clipPath id="winClip"><path d="M6 -30 L56 -30 Q88 -28 104 4 L6 4 Z"/></clipPath></defs>
          <g transform="translate(46 62) scale(.62)">${A.avatar('drive')}</g></g>
          <rect x="-150" y="-55" width="302" height="115" fill="transparent"/></g>`);
      s += `<path class="exhaust" d="M-170 -10 q-24 -8 -40 0 q-16 10 -34 0" transform="translate(470 470)" stroke="#fff" stroke-width="6" fill="none" opacity=".35" stroke-linecap="round"/>`;
    } else {
      const to = block && block.to ? DEST[block.to] : 'Destino';
      s += hot('sign', 'Señal de destino',
        `<g transform="translate(790 392)"><rect x="-3" y="-120" width="6" height="120" fill="#2A3140"/><rect x="-62" y="-130" width="124" height="38" rx="8" fill="#1B3558"/><path d="M-50 -111 h30 m-8 -8 l8 8 l-8 8" stroke="#FDCC0A" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/><text x="-14" y="-106" font-size="13" font-weight="800" fill="#fff" font-family="Inter,system-ui">${esc(to)}</text></g>`);
      s += `<ellipse cx="480" cy="428" rx="40" ry="7" fill="#000" opacity=".25"/>`;
      s += hot('avatar', 'Jherson caminando', `<g transform="translate(480 426) scale(1.08)">${A.avatar('walk', { mouth: 'open' })}<rect x="-40" y="-176" width="80" height="180" fill="transparent"/></g>`);
    }
    if (dk > 0.02) s += `<rect width="${W}" height="${H}" fill="#070B24" opacity="${dk * 0.32}" pointer-events="none"/>`;
    return s;
  }

  // ============================================================ GYM
  function gym(ctx) {
    const { h: hour, git, gymInfo } = ctx;
    const dark = night(hour) * 0.12;
    let s = `<rect width="${W}" height="400" fill="#2D4A52"/><rect y="300" width="${W}" height="100" fill="#264049"/><rect y="296" width="${W}" height="6" fill="#B9F03C" opacity=".9"/><rect y="400" width="${W}" height="140" fill="#262A31"/>`;
    for (let i = 0; i < 8; i++) s += `<path d="M0 ${412 + i * 18} H${W}" stroke="#1D2026" stroke-width="2"/>`;
    s += `<defs><linearGradient id="mirG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#CFE6F2"/><stop offset="1" stop-color="#8FB3C8"/></linearGradient></defs>`;
    s += `<rect x="150" y="84" width="380" height="250" rx="6" fill="#15181E"/><rect x="158" y="92" width="364" height="234" rx="3" fill="url(#mirG)"/>
      <path d="M200 326 L300 92 H340 L240 326 Z M350 326 L420 150 H440 L370 326 Z" fill="#fff" opacity=".25"/>`;
    s += `<text x="${W - 250}" y="90" text-anchor="middle" font-size="19" font-weight="900" fill="#B9F03C" font-family="Inter,system-ui" letter-spacing="1.5" style="filter:drop-shadow(0 0 6px #B9F03C)">UN PASO HOY.</text>
      <text x="${W - 250}" y="116" text-anchor="middle" font-size="19" font-weight="900" fill="#fff" font-family="Inter,system-ui" letter-spacing="1.5" style="filter:drop-shadow(0 0 6px #fff)">OTRO MAÑANA.</text>`;
    // pizarra de racha
    const st = (gymInfo && gymInfo.streak) || 0;
    s += hot('board', 'Pizarra de racha de gym',
      `<rect x="576" y="150" width="150" height="150" rx="8" fill="#fff"/><rect x="576" y="150" width="150" height="26" rx="8" fill="#B9F03C"/>
       <text x="651" y="168" text-anchor="middle" font-size="12" font-weight="800" fill="#15181E" font-family="Inter,system-ui">RACHA DE GYM</text>
       <text x="651" y="232" text-anchor="middle" font-size="52" font-weight="900" fill="#15181E" font-family="Inter,system-ui">${st}</text>
       <text x="651" y="250" text-anchor="middle" font-size="10" fill="#6B7280" font-family="Inter,system-ui">sesiones seguidas</text>
       ${Array.from({ length: 7 }, (_, i) => `<rect x="${590 + i * 17}" y="266" width="13" height="13" rx="3" fill="${i < Math.min(st, 7) ? '#B9F03C' : '#E5E7EB'}"/>`).join('')}
       <text x="651" y="292" text-anchor="middle" font-size="9" fill="#2C3E63" font-weight="700" font-family="Inter,system-ui">toca para marcar hoy</text>`);
    // rack con barra
    s += `<g><rect x="36" y="150" width="10" height="262" fill="#9AA5B1"/><rect x="132" y="150" width="10" height="262" fill="#9AA5B1"/><rect x="36" y="150" width="106" height="10" fill="#9AA5B1"/>
      <rect x="20" y="228" width="140" height="6" rx="3" fill="#C9CED6"/>
      ${[-1, 1].map((sd) => `<g transform="translate(${sd === -1 ? 30 : 150} 231)"><rect x="-6" y="-34" width="12" height="68" rx="4" fill="#15181E"/><rect x="-6" y="-26" width="12" height="52" rx="3" fill="#B9F03C" opacity=".9"/></g>`).join('')}</g>`;
    // banco
    s += `<rect x="560" y="420" width="140" height="22" rx="8" fill="#15181E"/><rect x="590" y="442" width="10" height="34" fill="#9AA5B1"/><rect x="660" y="442" width="10" height="34" fill="#9AA5B1"/>`;
    // mancuernas
    s += hot('weights', 'Rack de mancuernas',
      `<rect x="740" y="338" width="190" height="10" fill="#9AA5B1"/><rect x="750" y="348" width="8" height="120" fill="#9AA5B1"/><rect x="912" y="348" width="8" height="120" fill="#9AA5B1"/>
       <rect x="740" y="410" width="190" height="8" fill="#9AA5B1"/>
       ${[0, 1, 2, 3, 4].map((i) => `<g transform="translate(${772 + i * 30} 396)"><rect x="-10" y="-3" width="20" height="6" rx="2" fill="#6B7280"/><rect x="-13" y="-10" width="6" height="20" rx="2" fill="#2A3140"/><rect x="7" y="-10" width="6" height="20" rx="2" fill="#2A3140"/></g>`).join('')}
       ${[0, 1, 2, 3, 4].map((i) => `<g transform="translate(${772 + i * 30} 450)"><rect x="-11" y="-3" width="22" height="6" rx="2" fill="#6B7280"/><rect x="-15" y="-12" width="7" height="24" rx="2" fill="#B9F03C"/><rect x="8" y="-12" width="7" height="24" rx="2" fill="#B9F03C"/></g>`).join('')}`);
    s += `<ellipse cx="380" cy="488" rx="40" ry="8" fill="#000" opacity=".35"/>`;
    s += hot('avatar', 'Jherson entrenando', `<g transform="translate(380 486) scale(1.2)">${A.avatar('lift')}<rect x="-45" y="-176" width="90" height="180" fill="transparent"/></g>`);
    if (dark > 0.02) s += `<rect width="${W}" height="${H}" fill="#070B24" opacity="${dark}" pointer-events="none"/>`;
    return s;
  }

  const SCENE_OF = { dormir: 'casa', despertar: 'casa', libre: 'casa', descanso: 'casa', codigo: 'casa', estudio: 'uni', clases: 'uni', gym: 'gym', taxi: 'calle', camino: 'calle' };
  const FN = { casa, uni, calle, gym };
  window.Scenes = {
    sceneFor: (state) => SCENE_OF[state] || 'casa',
    render: (state, ctx) => FN[SCENE_OF[state] || 'casa']({ ...ctx, state }),
    night, skyAt, W, H,
  };
})();
