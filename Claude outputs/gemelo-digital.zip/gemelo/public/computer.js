// La computadora de la habitación: explorador de proyectos con interfaces reales (Claude Design),
// arquitectura, stack, actividad de git y pendientes.
window.Computer = (() => {
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const STATUS = {
    produccion: { n: 'En producción', c: '#B9F03C' }, desarrollo: { n: 'En desarrollo', c: '#6AD1FF' }, prototipo: { n: 'Prototipo', c: '#FDCC0A' },
  };
  const TABS = [['resumen', 'Resumen'], ['interfaces', 'Interfaces'], ['arquitectura', 'Arquitectura'], ['stack', 'Stack'], ['actividad', 'Actividad'], ['pendientes', 'Pendientes']];
  // Esta pantalla puede grabarse o mostrarse: no se muestra nada que parezca un secreto o una credencial.
  const SENSIBLE = /credencial|contraseñ|password|secret|api.?key|clave|token|\.env/i;
  const safe = (t) => !SENSIBLE.test(typeof t === 'string' ? t : (t && t.text) || '');

  let projects = null, gitData = null, root = null;
  let st = { slug: null, tab: 'resumen', group: null, idx: 0 };

  const css = `
  .pc{position:fixed;inset:0;z-index:60;background:rgba(5,8,18,.78);backdrop-filter:blur(8px);display:grid;place-items:center;padding:16px;animation:fadein .2s ease both}
  .pc-win{width:min(1180px,100%);height:min(780px,100%);display:flex;flex-direction:column;background:#0F1424;border:1px solid #2A3350;border-radius:18px;overflow:hidden;box-shadow:0 30px 80px rgba(0,0,0,.6)}
  .pc-bar{display:flex;align-items:center;gap:12px;padding:10px 14px;background:#161C30;border-bottom:1px solid #2A3350;font-size:13px}
  .pc-bar .lights{display:flex;gap:6px}.pc-bar .lights i{width:11px;height:11px;border-radius:50%;background:#FF6B6B}.pc-bar .lights i:nth-child(2){background:#FDCC0A}.pc-bar .lights i:nth-child(3){background:#B9F03C}
  .pc-bar .path{color:#9AA6C0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px}
  .pc-x{border:0;background:transparent;color:#9AA6C0;font-size:22px;width:34px;height:30px;border-radius:8px}.pc-x:hover{background:#2A3350;color:#fff}
  .pc-body{flex:1;min-height:0;display:flex}
  .pc-side{width:210px;flex:none;border-right:1px solid #2A3350;padding:12px;overflow:auto;background:#121830}
  .pc-side h4{margin:14px 6px 6px;font-size:10.5px;letter-spacing:.14em;text-transform:uppercase;color:#7C89A8}
  .pc-side button{display:flex;align-items:center;gap:9px;width:100%;text-align:left;border:0;background:transparent;padding:8px 10px;border-radius:9px;font-size:13.5px;font-weight:600;color:#DCE3F4}
  .pc-side button:hover{background:#1B2340}.pc-side button[aria-current="true"]{background:#242F55;color:#fff}
  .pc-side .dot{width:9px;height:9px;border-radius:50%}
  .pc-main{flex:1;min-width:0;overflow:auto;padding:22px}
  .pc-tabs{display:flex;gap:4px;flex-wrap:wrap;margin:14px 0 18px;border-bottom:1px solid #2A3350}
  .pc-tabs button{border:0;background:transparent;color:#9AA6C0;padding:9px 13px;font-weight:700;font-size:13.5px;border-bottom:2px solid transparent;margin-bottom:-1px}
  .pc-tabs button:hover{color:#fff}.pc-tabs button[aria-selected="true"]{color:#B9F03C;border-color:#B9F03C}
  .pc h1{margin:0;font-size:26px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}.pc .tag{font-size:12px;padding:4px 10px;border-radius:999px;color:#0E1220;font-weight:800}
  .pc .lead{color:#B8C2DA;margin:6px 0 0;font-size:15px;line-height:1.5}
  .pc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
  .pc-card{text-align:left;border:1px solid #2A3350;background:#161C30;border-radius:16px;padding:16px;color:inherit;transition:.15s}.pc-card:hover{border-color:#B9F03C;transform:translateY(-2px)}
  .pc-card b{display:block;font-size:17px;margin:10px 0 4px}.pc-card span{color:#9AA6C0;font-size:13px;line-height:1.4;display:block}
  .folder{width:46px;height:36px;border-radius:6px 10px 8px 8px;background:var(--c);position:relative}.folder::before{content:"";position:absolute;left:0;top:-7px;width:20px;height:9px;border-radius:5px 5px 0 0;background:var(--c)}
  .metrics{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px;margin-top:6px}
  .metric{background:#161C30;border:1px solid #2A3350;border-radius:12px;padding:12px}.metric em{display:block;font-style:normal;font-size:12px;color:#9AA6C0;margin-bottom:3px}.metric b{font-size:15px}
  .pc h3{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#7C89A8;margin:22px 0 10px}
  .pc-note{margin-top:10px;padding:10px 12px;border-radius:12px;background:#1B2340;border:1px solid #2A3350;color:#B8C2DA;font-size:13.5px;line-height:1.45}
  .viewer{display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap}
  .phone{flex:none;width:min(300px,100%);background:#05070F;border:2px solid #2A3350;border-radius:36px;padding:10px;box-shadow:0 20px 50px rgba(0,0,0,.5)}
  .phone img{display:block;width:100%;height:auto;border-radius:26px;background:#10152A;cursor:zoom-in}
  .phone.wide{width:min(660px,100%);border-radius:22px;padding:8px}.phone.wide img{border-radius:14px}
  .vinfo{flex:1;min-width:240px}.vinfo h2{margin:0 0 4px;font-size:20px}.vinfo .muted{color:#9AA6C0;font-size:13px}
  .chips{display:flex;gap:6px;flex-wrap:wrap;margin:12px 0}.chips button{border:1px solid #2A3350;background:#161C30;color:#DCE3F4;padding:6px 12px;border-radius:999px;font-size:12.5px;font-weight:700}.chips button[aria-pressed="true"]{background:#B9F03C;color:#0E1220;border-color:#B9F03C}
  .pager{display:flex;gap:8px;align-items:center;margin:10px 0}.pager button{border:1px solid #2A3350;background:#161C30;color:#fff;padding:8px 14px;border-radius:10px;font-weight:700}.pager button:hover{border-color:#B9F03C}.pager button:disabled{opacity:.35;cursor:default}
  .thumbs{display:flex;gap:8px;overflow:auto;padding:6px 2px 10px}.thumbs button{flex:none;width:64px;border:2px solid transparent;border-radius:10px;padding:0;background:#10152A;overflow:hidden}.thumbs button[aria-current="true"]{border-color:#B9F03C}.thumbs img{display:block;width:100%;height:auto}
  .layer{border:1px solid #2A3350;background:#161C30;border-radius:14px;padding:12px 14px}.layer b{font-size:13px;letter-spacing:.05em;text-transform:uppercase;color:#B9F03C}.layer .items{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.layer .items span{background:#0F1424;border:1px solid #2A3350;border-radius:8px;padding:5px 9px;font-size:12.5px}
  .link{display:flex;flex-direction:column;align-items:center;padding:4px 0;color:#7C89A8;font-size:12px}.link i{display:block;width:2px;height:14px;background:#3A4670}.link span{padding:2px 0}.link svg{display:block}
  .stackg{margin-bottom:14px}.stackg h4{margin:0 0 8px;font-size:12px;color:#9AA6C0;letter-spacing:.1em;text-transform:uppercase}.stackg ul{margin:0;padding:0;list-style:none;display:flex;gap:8px;flex-wrap:wrap}.stackg li{background:#161C30;border:1px solid #2A3350;border-radius:12px;padding:8px 12px;font-size:13.5px}.stackg li small{display:block;color:#9AA6C0;margin-top:2px;font-size:12px}
  .commits{list-style:none;margin:0;padding:0;display:grid;gap:6px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12.5px}.commits li{display:flex;gap:10px;background:#0A0F1C;border:1px solid #2A3350;border-radius:10px;padding:8px 10px}.commits .h{color:#FDCC0A}.commits .t{color:#7C89A8;margin-left:auto;white-space:nowrap}.commits .m{color:#DCE3F4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .plist{list-style:none;margin:0;padding:0;display:grid;gap:8px}.plist li{background:#161C30;border:1px solid #2A3350;border-radius:12px;padding:10px 14px;font-size:14px;line-height:1.4}.plist small{display:block;color:#7C89A8;margin-top:3px;font-size:12px}
  .lightbox{position:fixed;inset:0;z-index:70;background:rgba(0,0,0,.88);display:grid;place-items:center;padding:20px;cursor:zoom-out}.lightbox img{max-height:94vh;max-width:94vw;border-radius:22px}
  @media (max-width:760px){.pc{padding:0}.pc-win{border-radius:0;height:100%}.pc-body{flex-direction:column}.pc-side{width:auto;border-right:0;border-bottom:1px solid #2A3350;display:flex;gap:4px;overflow:auto;padding:8px}.pc-side h4{display:none}.pc-side button{width:auto;white-space:nowrap;flex:none}.pc-main{padding:16px}.phone{margin:0 auto}}
  `;
  function ensureStyle() { if (!document.getElementById('pc-style')) { const s = document.createElement('style'); s.id = 'pc-style'; s.textContent = css; document.head.appendChild(s); } }

  async function load() {
    if (!projects) projects = (await fetch('/api/projects').then((r) => r.json())).projects || [];
    try { gitData = await fetch('/api/git').then((r) => r.json()); } catch { gitData = null; }
  }
  const proj = () => projects.find((p) => p.slug === st.slug);
  const rel = (ts) => { const m = Math.max(0, Math.round((Date.now() - ts) / 60000)); if (m < 60) return `hace ${m} min`; if (m < 1440) return `hace ${Math.round(m / 60)} h`; return `hace ${Math.round(m / 1440)} d`; };

  // ---------------------------------------------------------------- vistas
  function side() {
    const groups = [['produccion', 'En producción'], ['desarrollo', 'En desarrollo'], ['prototipo', 'Prototipos']];
    let h = `<button type="button" data-go="desk" aria-current="${!st.slug}"><span class="dot" style="background:#9AA6C0"></span>Escritorio</button>`;
    for (const [k, label] of groups) {
      const list = projects.filter((p) => p.status === k); if (!list.length) continue;
      h += `<h4>${label}</h4>` + list.map((p) => `<button type="button" data-go="${esc(p.slug)}" aria-current="${st.slug === p.slug}"><span class="dot" style="background:${STATUS[k].c}"></span>${esc(p.name)}</button>`).join('');
    }
    return h;
  }
  function desk() {
    return `<h1>Mis proyectos</h1><p class="lead">Toca una carpeta. Las interfaces son tus diseños de Claude Design; el stack y la arquitectura salen de leer el código.</p>
      <h3>Carpetas</h3><div class="pc-grid">${projects.map((p) => {
      const s = STATUS[p.status] || STATUS.desarrollo;
      return `<button class="pc-card" type="button" data-go="${esc(p.slug)}"><div class="folder" style="--c:${s.c}"></div><b>${esc(p.name)}</b><span>${esc(p.tagline)}</span><span style="margin-top:8px"><b style="display:inline;font-size:12px;color:${s.c}">${s.n}</b>${p.screens && p.screens.length ? ` · ${p.screens.length} pantallas` : ''}</span></button>`;
    }).join('')}</div>`;
  }
  function header(p) {
    const s = STATUS[p.status] || STATUS.desarrollo;
    return `<h1>${esc(p.name)} <span class="tag" style="background:${s.c}">${s.n}</span></h1><p class="lead">${esc(p.tagline)}</p>
      <div class="pc-tabs" role="tablist">${TABS.map(([k, n]) => `<button type="button" role="tab" data-tab="${k}" aria-selected="${st.tab === k}">${n}${k === 'interfaces' && p.screens && p.screens.length ? ` (${p.screens.length})` : ''}</button>`).join('')}</div>`;
  }
  function tabResumen(p) {
    const notes = (p.notes || []).filter(safe);
    return `<p class="lead" style="margin-top:0">${esc(p.summary)}</p>
      ${p.statusNote && safe(p.statusNote) ? `<div class="pc-note"><b>Estado:</b> ${esc(p.statusNote)}</div>` : ''}
      <h3>En números</h3><div class="metrics">${(p.metrics || []).map((m) => `<div class="metric"><em>${esc(m.label)}</em><b>${esc(m.value)}</b></div>`).join('')}</div>
      ${notes.length ? `<h3>Notas</h3>${notes.map((n) => `<div class="pc-note">${esc(typeof n === 'string' ? n : n.text)}</div>`).join('')}` : ''}
      ${p.unverified && p.unverified.length ? `<h3>Sin verificar</h3><ul class="plist">${p.unverified.filter(safe).map((u) => `<li>${esc(u)}</li>`).join('')}</ul>` : ''}`;
  }
  function tabInterfaces(p) {
    const all = p.screens || [];
    if (!all.length) return `<div class="pc-note">Todavía no hay pantallas para este proyecto.</div>`;
    const groups = [...new Set(all.map((s) => s.group || 'Pantallas'))];
    if (!st.group || !groups.includes(st.group)) { st.group = groups[0]; st.idx = 0; }
    const list = all.filter((s) => (s.group || 'Pantallas') === st.group);
    st.idx = Math.min(Math.max(st.idx, 0), list.length - 1);
    const s = list[st.idx];
    return `<div class="viewer">
      <div class="phone"><img id="shot" src="${esc(s.url)}" alt="${esc(s.title)}" data-zoom="1"></div>
      <div class="vinfo">
        ${groups.length > 1 ? `<div class="chips" role="group" aria-label="Grupo de pantallas">${groups.map((g) => `<button type="button" data-group="${esc(g)}" aria-pressed="${g === st.group}">${esc(g)}</button>`).join('')}</div>` : ''}
        <h2>${esc(s.title)}</h2><div class="muted">${st.idx + 1} de ${list.length} · ${esc(st.group)}</div>
        <div class="pager"><button type="button" id="prev" ${st.idx === 0 ? 'disabled' : ''}>← Anterior</button><button type="button" id="next" ${st.idx === list.length - 1 ? 'disabled' : ''}>Siguiente →</button></div>
        <div class="thumbs">${list.map((x, i) => `<button type="button" data-i="${i}" aria-current="${i === st.idx}" title="${esc(x.title)}"><img loading="lazy" src="${esc(x.url)}" alt="${esc(x.title)}"></button>`).join('')}</div>
        <p class="muted">Diseños de Claude Design, renderizados tal como se ven en el lienzo. Usa las flechas del teclado para navegar.</p>
      </div></div>`;
  }
  function tabArq(p) {
    const A = p.architecture; if (!A || !A.layers) return '<div class="pc-note">Sin diagrama.</div>';
    const idx = Object.fromEntries(A.layers.map((l, i) => [l.id, i]));
    const between = {}, other = [];
    for (const f of A.flows || []) {
      const a = idx[f.from], b = idx[f.to];
      if (a == null || b == null) continue;
      if (Math.abs(a - b) === 1) { const k = Math.min(a, b); (between[k] = between[k] || []).push(f); } else other.push(f);
    }
    let h = '';
    A.layers.forEach((l, i) => {
      h += `<div class="layer"><b>${esc(l.label)}</b><div class="items">${(l.items || []).map((x) => `<span>${esc(x)}</span>`).join('')}</div></div>`;
      if (i < A.layers.length - 1) {
        const fs = between[i] || [];
        h += `<div class="link"><i></i>${fs.map((f) => `<span>${idx[f.from] < idx[f.to] ? '↓' : '↑'} ${esc(f.label)}</span>`).join('') || ''}<i></i></div>`;
      }
    });
    if (other.length) h += `<h3>Otras conexiones</h3><ul class="plist">${other.map((f) => `<li>${esc((A.layers[idx[f.from]] || {}).label)} → ${esc((A.layers[idx[f.to]] || {}).label)}<small>${esc(f.label)}</small></li>`).join('')}</ul>`;
    return `<div style="max-width:760px">${h}</div><p class="lead" style="font-size:13px;margin-top:16px;color:#7C89A8">Diagrama simplificado, armado leyendo el código del proyecto.</p>`;
  }
  function tabStack(p) {
    const groups = {};
    for (const s of p.stack || []) (groups[s.group || 'Otros'] = groups[s.group || 'Otros'] || []).push(s);
    return Object.entries(groups).map(([g, l]) => `<div class="stackg"><h4>${esc(g)}</h4><ul>${l.map((s) => `<li><b>${esc(s.name)}</b><small>${esc(s.role)}</small></li>`).join('')}</ul></div>`).join('') || '<div class="pc-note">Sin datos.</div>';
  }
  function tabAct(p) {
    const lc = p.lastCommit;
    let h = `<div class="metrics">
      ${lc ? `<div class="metric"><em>Último commit (al leer el código)</em><b>${esc(lc.date)}</b></div>` : ''}
      ${p.commits30d != null ? `<div class="metric"><em>Commits en 30 días</em><b>${esc(p.commits30d)}</b></div>` : ''}
      ${p.uncommittedFiles != null ? `<div class="metric"><em>Archivos sin commit</em><b>${esc(p.uncommittedFiles)}</b></div>` : ''}</div>`;
    const r = gitData && gitData.repos ? gitData.repos.find((x) => x.slug === p.slug) : null;
    h += '<h3>En vivo desde tu computadora</h3>';
    if (!gitData || !gitData.configured) h += '<div class="pc-note">No hay repositorios configurados. Edita <code>data/config.json</code>.</div>';
    else if (!r) h += '<div class="pc-note">Este proyecto no tiene carpeta configurada en <code>data/config.json</code>.</div>';
    else if (!r.ok) h += `<div class="pc-note">No pude leer el repositorio: ${esc(r.reason)}.</div>`;
    else {
      h += `<p class="lead" style="margin:0 0 10px;font-size:14px">Hoy: <b>${r.today.length}</b> commit${r.today.length === 1 ? '' : 's'} · ${r.dirtyFiles} archivo${r.dirtyFiles === 1 ? '' : 's'} sin commit</p>
        <ul class="commits">${r.recent.map((c) => `<li><span class="h">${esc(c.hash)}</span><span class="m">${esc(c.msg)}</span><span class="t">${rel(c.ts)}</span></li>`).join('') || '<li>Sin commits.</li>'}</ul>`;
    }
    return h;
  }
  function tabPend(p) {
    const items = (p.pending || []).filter(safe);
    return items.length ? `<ul class="plist">${items.map((x) => `<li>${esc(typeof x === 'string' ? x : x.text)}${x.from ? `<small>${esc(x.from)}</small>` : ''}</li>`).join('')}</ul>` : '<div class="pc-note">Nada pendiente registrado.</div>';
  }

  // ---------------------------------------------------------------- montaje
  function paint() {
    if (!root) return;
    const p = proj();
    root.querySelector('.path').textContent = '~/Proyectos' + (p ? ' / ' + p.name : '');
    root.querySelector('.pc-side').innerHTML = side();
    const main = root.querySelector('.pc-main');
    if (!p) { main.innerHTML = desk(); return; }
    const body = { resumen: tabResumen, interfaces: tabInterfaces, arquitectura: tabArq, stack: tabStack, actividad: tabAct, pendientes: tabPend }[st.tab](p);
    main.innerHTML = header(p) + body;
    const shot = main.querySelector('#shot');
    if (shot) { const fit = () => { if (shot.naturalWidth > shot.naturalHeight) shot.parentElement.classList.add('wide'); }; if (shot.complete) fit(); else shot.addEventListener('load', fit); }
  }
  function onClick(e) {
    const t = e.target;
    const go = t.closest('[data-go]'); if (go) { st = { slug: go.dataset.go === 'desk' ? null : go.dataset.go, tab: 'resumen', group: null, idx: 0 }; paint(); return; }
    const tab = t.closest('[data-tab]'); if (tab) { st.tab = tab.dataset.tab; paint(); return; }
    const grp = t.closest('[data-group]'); if (grp) { st.group = grp.dataset.group; st.idx = 0; paint(); return; }
    const th = t.closest('.thumbs [data-i]'); if (th) { st.idx = Number(th.dataset.i); paint(); return; }
    if (t.closest('#prev')) { st.idx--; paint(); return; }
    if (t.closest('#next')) { st.idx++; paint(); return; }
    if (t.closest('[data-zoom]')) { const lb = document.createElement('div'); lb.className = 'lightbox'; lb.innerHTML = `<img src="${esc(t.src)}" alt="">`; lb.onclick = () => lb.remove(); document.body.appendChild(lb); return; }
    if (t.closest('.pc-x') || t === root) close();
  }
  function onKey(e) {
    if (!root) return;
    const lb = document.querySelector('.lightbox');
    if (e.key === 'Escape') { if (lb) lb.remove(); else close(); return; }
    if (st.tab === 'interfaces' && st.slug) {
      if (e.key === 'ArrowRight') { st.idx++; paint(); } else if (e.key === 'ArrowLeft') { st.idx--; paint(); }
    }
  }
  async function open(opt = {}) {
    ensureStyle(); await load();
    st = { slug: opt.slug && projects.some((p) => p.slug === opt.slug) ? opt.slug : null, tab: opt.tab || 'resumen', group: null, idx: 0 };
    if (!root) {
      root = document.createElement('div'); root.className = 'pc';
      root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-label', 'Computadora con mis proyectos');
      root.innerHTML = `<div class="pc-win"><div class="pc-bar"><span class="lights"><i></i><i></i><i></i></span><b>Jherson-PC</b><span class="path"></span><button class="pc-x" type="button" aria-label="Cerrar">×</button></div><div class="pc-body"><nav class="pc-side" aria-label="Proyectos"></nav><section class="pc-main"></section></div></div>`;
      root.addEventListener('click', onClick); document.addEventListener('keydown', onKey);
      document.body.appendChild(root);
    }
    paint();
    const x = root.querySelector('.pc-x'); if (x) x.focus();
  }
  function close() { if (root) { root.remove(); root = null; document.removeEventListener('keydown', onKey); } }
  return { open, close, isOpen: () => !!root };
})();
