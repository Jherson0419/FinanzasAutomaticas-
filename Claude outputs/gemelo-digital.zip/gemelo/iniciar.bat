@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Necesitas instalar Node.js desde https://nodejs.org & pause & exit /b 1)
start "" http://localhost:3737
node server.js
pause
