#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Instala Node.js desde https://nodejs.org"; exit 1; }
node server.js
